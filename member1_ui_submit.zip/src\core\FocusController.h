#ifndef FOCUSCONTROLLER_H
#define FOCUSCONTROLLER_H

#include <QObject>
#include <QString>
#include <QList>

struct PlantInfo {
    int id = 0;
    QString typeName;           // "OakTree", "Rose" 等
    int growthStage = 0;        // 0=Seed 1=Sprout 2=Growing 3=Mature 4=Withered
    int gridRow = 0;
    int gridCol = 0;
    bool unlocked = false;
    int unlockPrice = 0;
};

struct FocusSessionInfo {
    int plantType = -1;
    int durationMinutes = 0;
    int remainingSeconds = 0;
};

class FocusController : public QObject {
    Q_OBJECT
public:
    enum class State { IDLE, FOCUSING, PAUSED, SUCCESS, FAILED };

    virtual ~FocusController() = default;

    virtual State state() const = 0;
    virtual const QList<PlantInfo>& plants() const = 0;
    virtual const FocusSessionInfo& sessionInfo() const = 0;
    virtual int coinBalance() const = 0;
    virtual QStringList blacklist() const = 0;
    virtual QStringList whitelist() const = 0;

public slots:
    virtual void startFocus(int plantType, int durationMinutes) = 0;
    virtual void pause() = 0;
    virtual void resume() = 0;
    virtual void abandon() = 0;
    virtual void unlockPlant(int plantId) = 0;
    virtual void addBlacklist(const QString& process) = 0;
    virtual void removeBlacklist(const QString& process) = 0;
    virtual void setStrictMode(bool strict) = 0;

signals:
    void stateChanged(int newState);
    void tick(int remainingSeconds, int totalSeconds);
    void plantGrown(int plantId, int newStage);
    void sessionFinished(bool success, int coinsEarned);
    void coinBalanceChanged(int newBalance);
    void plantUnlocked(int plantId);
    void achievementEarned(const QString& name, const QString& description);
};

#endif // FOCUSCONTROLLER_H

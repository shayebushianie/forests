#include <QApplication>
#include <QFile>
#include "ui/MainWindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.setApplicationName("FocusForest");
    app.setApplicationVersion("1.0.0");

    QFile qssFile(":/style.qss");
    if (qssFile.open(QFile::ReadOnly)) {
        app.setStyleSheet(qssFile.readAll());
        qssFile.close();
    }

    MainWindow w;
    w.show();
    return app.exec();
}

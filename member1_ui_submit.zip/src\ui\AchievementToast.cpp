#include "ui/AchievementToast.h"
#include <QPainter>
#include <QPainterPath>
#include <QFont>
#include <QGraphicsDropShadowEffect>

AchievementToast::AchievementToast(QWidget *parent)
    : QWidget(parent)
{
    setupUI();
    hide();
}

void AchievementToast::setupUI()
{
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint |
                   Qt::Tool | Qt::SubWindow);
    setAttribute(Qt::WA_TranslucentBackground);
    setAttribute(Qt::WA_ShowWithoutActivating);
    setFixedSize(280, 100);

    m_opacityEffect = new QGraphicsOpacityEffect(this);
    m_opacityEffect->setOpacity(1.0);
    setGraphicsEffect(m_opacityEffect);

    auto *layout = new QVBoxLayout(this);
    layout->setContentsMargins(20, 16, 20, 16);
    layout->setSpacing(4);

    m_iconLabel = new QLabel("🏆");
    m_iconLabel->setAlignment(Qt::AlignCenter);
    m_iconLabel->setStyleSheet("font-size: 22px;");

    m_nameLabel = new QLabel;
    m_nameLabel->setObjectName("achievementName");
    m_nameLabel->setAlignment(Qt::AlignCenter);

    m_descLabel = new QLabel;
    m_descLabel->setObjectName("achievementDesc");
    m_descLabel->setAlignment(Qt::AlignCenter);
    m_descLabel->setWordWrap(true);

    layout->addWidget(m_iconLabel);
    layout->addWidget(m_nameLabel);
    layout->addWidget(m_descLabel);

    m_opacityEffect = new QGraphicsOpacityEffect(this);
    m_opacityEffect->setOpacity(1.0);
    setGraphicsEffect(m_opacityEffect);

    // 3秒后自动隐藏
    m_hideTimer = new QTimer(this);
    m_hideTimer->setSingleShot(true);
    connect(m_hideTimer, &QTimer::timeout, this, [this]() {
        m_fadeAnim = new QPropertyAnimation(m_opacityEffect, "opacity");
        m_fadeAnim->setDuration(500);
        m_fadeAnim->setStartValue(1.0);
        m_fadeAnim->setEndValue(0.0);
        connect(m_fadeAnim, &QPropertyAnimation::finished, this, &QWidget::hide);
        m_fadeAnim->start(QAbstractAnimation::DeleteWhenStopped);
    });
}

void AchievementToast::showAchievement(const QString &name, const QString &desc)
{
    m_nameLabel->setText(name);
    m_descLabel->setText(desc);

    // 定位到父窗口右下角
    if (parentWidget()) {
        QPoint parentBR = parentWidget()->mapToGlobal(
            QPoint(parentWidget()->width(), parentWidget()->height()));
        move(parentBR.x() - width() - 20, parentBR.y() - height() - 20);
    }

    m_opacityEffect->setOpacity(1.0);
    show();
    raise();
    m_hideTimer->start(3000);
}

void AchievementToast::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    // 金边卡片背景
    QPainterPath path;
    path.addRoundedRect(rect(), 12, 12);
    p.fillPath(path, QColor(30, 40, 30, 240));
    p.setPen(QPen(QColor("#FFD700"), 2));
    p.drawPath(path);
}

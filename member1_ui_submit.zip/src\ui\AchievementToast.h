#ifndef ACHIEVEMENTTOAST_H
#define ACHIEVEMENTTOAST_H

#include <QWidget>
#include <QLabel>
#include <QTimer>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>
#include <QVBoxLayout>

/**
 * @brief 成就解锁弹出提示组件，金边半透明 + 淡入淡出动画
 *
 * 使用 QPropertyAnimation + QGraphicsOpacityEffect 实现弹出渐显、
 * 3 秒后自动渐隐消失的效果。
 */
class AchievementToast : public QWidget {
    Q_OBJECT
    Q_PROPERTY(qreal windowOpacity READ windowOpacity WRITE setWindowOpacity)
public:
    explicit AchievementToast(QWidget *parent = nullptr);

    /**
     * @brief 触发成就弹出动画
     * @param name 成就名称
     * @param desc 成就描述
     */
    void showAchievement(const QString &name, const QString &desc);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    void setupUI();
    void playAnimation();

    QLabel *m_iconLabel = nullptr;
    QLabel *m_nameLabel = nullptr;
    QLabel *m_descLabel = nullptr;
    QTimer *m_hideTimer = nullptr;
    QGraphicsOpacityEffect *m_opacityEffect = nullptr;
    QPropertyAnimation *m_fadeAnim = nullptr;
};

#endif // ACHIEVEMENTTOAST_H

#ifndef ACHIEVEMENTTOAST_H
#define ACHIEVEMENTTOAST_H

#include <QWidget>
#include <QLabel>
#include <QTimer>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>
#include <QVBoxLayout>

class AchievementToast : public QWidget {
    Q_OBJECT
    Q_PROPERTY(qreal windowOpacity READ windowOpacity WRITE setWindowOpacity)
public:
    explicit AchievementToast(QWidget *parent = nullptr);

    void showAchievement(const QString &name, const QString &desc);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    void setupUI();
    void playAnimation();

    QLabel *m_iconLabel = nullptr;
    QLabel *m_nameLabel = nullptr;
    QLabel *m_descLabel = nullptr;
    QTimer *m_hideTimer = nullptr;
    QGraphicsOpacityEffect *m_opacityEffect = nullptr;
    QPropertyAnimation *m_fadeAnim = nullptr;
};

#endif // ACHIEVEMENTTOAST_H

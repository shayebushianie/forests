#include "ui/GardenCanvas.h"
#include <QPainterPath>
#include <QFont>

GardenCanvas::GardenCanvas(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(300, 240);
    setMouseTracking(false);

    // ⚠️ 关键：构造函数中一次性加载所有植物阶段图片到缓存
    // 图片路径对应 resources.qrc 里的别名
    QStringList types = {"OakTree", "PineTree", "Rose", "Sunflower"};
    for (const auto &t : types) {
        QList<QPixmap> stages;
        for (int s = 0; s < 5; s++) {
            QString path = QString(":/icons/%1_stage%2.png").arg(t.toLower()).arg(s);
            QPixmap pm(path);
            if (pm.isNull()) {
                // 降级：用纯色方块代替
                pm = QPixmap(64, 64);
                pm.fill(QColor(100 + s * 30, 150, 80));
            }
            stages.append(pm);
        }
        m_pixmapCache[t] = stages;
    }
}

void GardenCanvas::setGridSize(int rows, int cols)
{
    m_rows = rows;
    m_cols = cols;
    update();
}

void GardenCanvas::setPlants(const QList<GardenPlant> &plants)
{
    m_plants = plants;
    update();
}

void GardenCanvas::onPlantGrown(int plantId, int newStage)
{
    for (auto &p : m_plants) {
        if (p.id == plantId) {
            p.growthStage = newStage;
            update();
            break;
        }
    }
}

void GardenCanvas::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    // 背景
    p.fillRect(rect(), QColor("#1B2E1B"));

    // 计算格子尺寸
    m_cellW = (width() - m_marginX * 2) / m_cols;
    m_cellH = (height() - m_marginY * 2) / m_rows;

    drawGrid(p);
    drawPlants(p);
}

void GardenCanvas::drawGrid(QPainter &p)
{
    QPen gridPen(QColor("#2D4A2D"), 1, Qt::SolidLine);
    p.setPen(gridPen);

    for (int r = 0; r <= m_rows; r++) {
        p.drawLine(QPointF(m_marginX, m_marginY + r * m_cellH),
                   QPointF(m_marginX + m_cols * m_cellW, m_marginY + r * m_cellH));
    }
    for (int c = 0; c <= m_cols; c++) {
        p.drawLine(QPointF(m_marginX + c * m_cellW, m_marginY),
                   QPointF(m_marginX + c * m_cellW, m_marginY + m_rows * m_cellH));
    }
}

void GardenCanvas::drawPlants(QPainter &p)
{
    for (const auto &plant : m_plants) {
        QRectF cr = cellRect(plant.row, plant.col);
        QPixmap pm = stagePixmap(plant.typeName, plant.growthStage);

        qreal scale = qMin(cr.width(), cr.height()) * 0.7 / qMax(pm.width(), pm.height());
        qreal pw = pm.width() * scale;
        qreal ph = pm.height() * scale;
        qreal px = cr.center().x() - pw / 2;
        qreal py = cr.center().y() - ph / 2;

        p.drawPixmap(QRectF(px, py, pw, ph).toRect(), pm);

        // 植物类型名
        QFont f("Microsoft YaHei", 8);
        p.setFont(f);
        p.setPen(QColor("#A0B0A0"));
        p.drawText(QRectF(cr.left(), cr.bottom() - 16, cr.width(), 14),
                   Qt::AlignCenter, plant.typeName);
    }
}

QRectF GardenCanvas::cellRect(int row, int col) const
{
    return QRectF(m_marginX + col * m_cellW,
                  m_marginY + row * m_cellH,
                  m_cellW, m_cellH);
}

QPixmap GardenCanvas::stagePixmap(const QString &typeName, int stage) const
{
    if (m_pixmapCache.contains(typeName)) {
        const auto &stages = m_pixmapCache[typeName];
        int idx = qBound(0, stage, stages.size() - 1);
        return stages[idx];
    }
    QPixmap fallback(64, 64);
    fallback.fill(Qt::darkGreen);
    return fallback;
}

void GardenCanvas::mousePressEvent(QMouseEvent *event)
{
    if (event->button() != Qt::LeftButton) return;
    QPointF pos = event->position();

    for (const auto &plant : m_plants) {
        QRectF cr = cellRect(plant.row, plant.col);
        if (cr.contains(pos)) {
            emit plantClicked(plant.id);
            return;
        }
    }

    int col = (pos.x() - m_marginX) / m_cellW;
    int row = (pos.y() - m_marginY) / m_cellH;
    if (row >= 0 && row < m_rows && col >= 0 && col < m_cols) {
        emit cellClicked(row, col);
    }
}

void GardenCanvas::resizeEvent(QResizeEvent *)
{
    m_cellW = (width() - m_marginX * 2) / m_cols;
    m_cellH = (height() - m_marginY * 2) / m_rows;
}

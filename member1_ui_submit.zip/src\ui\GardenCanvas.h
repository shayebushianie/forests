#ifndef GARDENCANVAS_H
#define GARDENCANVAS_H

#include <QWidget>
#include <QPainter>
#include <QPixmap>
#include <QMap>
#include <QMouseEvent>

struct GardenPlant {
    int id = 0;
    QString typeName;
    int growthStage = 0;      // 0-4
    int row = 0;
    int col = 0;
};

class GardenCanvas : public QWidget {
    Q_OBJECT
public:
    explicit GardenCanvas(QWidget *parent = nullptr);

    void setGridSize(int rows, int cols);
    void setPlants(const QList<GardenPlant> &plants);

public slots:
    void onPlantGrown(int plantId, int newStage);

signals:
    void cellClicked(int row, int col);
    void plantClicked(int plantId);

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private:
    void drawGrid(QPainter &p);
    void drawPlants(QPainter &p);
    QRectF cellRect(int row, int col) const;
    QPixmap stagePixmap(const QString &typeName, int stage) const;

    int m_rows = 4;
    int m_cols = 5;
    qreal m_cellW = 0, m_cellH = 0;
    qreal m_marginX = 20, m_marginY = 20;

    QList<GardenPlant> m_plants;
    QMap<QString, QList<QPixmap>> m_pixmapCache;   // 类型 → 五个阶段的图
};

#endif // GARDENCANVAS_H

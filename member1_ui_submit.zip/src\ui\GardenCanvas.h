#ifndef GARDENCANVAS_H
#define GARDENCANVAS_H

#include <QWidget>
#include <QPainter>
#include <QPixmap>
#include <QMap>
#include <QMouseEvent>

/**
 * @brief 植物在画布上的显示数据
 */
struct GardenPlant {
    int id = 0;
    QString typeName;
    int growthStage = 0;      // 0=种子, 1=幼苗, 2=生长期, 3=成熟, 4=枯萎
    int row = 0;
    int col = 0;
};

/**
 * @brief 森林画布组件，使用 QPainter 绘制 4×5 网格植物
 *
 * 根据植物类型和生长阶段从缓存中获取对应图标进行绘制，
 * 支持点击选中植物单元格，预留自定义位置接口。
 */
class GardenCanvas : public QWidget {
    Q_OBJECT
public:
    explicit GardenCanvas(QWidget *parent = nullptr);

    /**
     * @brief 设置画布网格大小
     * @param rows 行数（默认 4）
     * @param cols 列数（默认 5）
     */
    void setGridSize(int rows, int cols);

    /**
     * @brief 刷新画布中的植物列表
     * @param plants 植物数据列表
     */
    void setPlants(const QList<GardenPlant> &plants);

public slots:
    /**
     * @brief 某株植物生长阶段更新，触发局部重绘
     * @param plantId 植物 ID
     * @param newStage 新的生长阶段（0-4）
     */
    void onPlantGrown(int plantId, int newStage);

signals:
    /** 点击了某个空格子 */
    void cellClicked(int row, int col);
    /** 点击了某株植物 */
    void plantClicked(int plantId);

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private:
    void drawGrid(QPainter &p);
    void drawPlants(QPainter &p);
    QRectF cellRect(int row, int col) const;
    QPixmap stagePixmap(const QString &typeName, int stage) const;

    int m_rows = 4;
    int m_cols = 5;
    qreal m_cellW = 0, m_cellH = 0;
    qreal m_marginX = 20, m_marginY = 20;

    QList<GardenPlant> m_plants;
    QMap<QString, QList<QPixmap>> m_pixmapCache;   // 类型 → 五个阶段的图
};

#endif // GARDENCANVAS_H

#include "ui/GridSelectDialog.h"
#include <QFont>
#include <QStyle>

GridSelectDialog::GridSelectDialog(int rows, int cols,
                                   const QList<QPoint> &occupied,
                                   QWidget *parent)
    : QDialog(parent), m_rows(rows), m_cols(cols), m_occupied(occupied)
{
    setWindowTitle("选择种植位置");
    setFixedSize(480, 520);
    setObjectName("gridSelectDialog");
    setupUI();
}

void GridSelectDialog::setupUI()
{
    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(12);
    mainLayout->setContentsMargins(20, 20, 20, 20);

    auto *title = new QLabel("选择森林中的一块空地");
    title->setObjectName("dialogTitle");
    QFont f("Microsoft YaHei", 14);
    title->setFont(f);
    title->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(title);

    m_statusLabel = new QLabel("请点击目标位置");
    m_statusLabel->setObjectName("hintLabel");
    m_statusLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(m_statusLabel);

    m_grid = new QGridLayout;
    m_grid->setSpacing(4);

    for (int r = 0; r < m_rows; r++) {
        for (int c = 0; c < m_cols; c++) {
            bool occ = m_occupied.contains(QPoint(r, c));
            auto *btn = createCell(r, c, occ);
            m_grid->addWidget(btn, r, c);
            m_cells.append(btn);
        }
    }

    mainLayout->addLayout(m_grid);

    auto *btnRow = new QHBoxLayout;
    auto *cancelBtn = new QPushButton("取消");
    cancelBtn->setObjectName("secondaryBtn");
    auto *confirmBtn = new QPushButton("确认种植");
    confirmBtn->setObjectName("primaryBtn");
    confirmBtn->setEnabled(false);

    btnRow->addStretch();
    btnRow->addWidget(cancelBtn);
    btnRow->addWidget(confirmBtn);
    mainLayout->addLayout(btnRow);

    connect(cancelBtn, &QPushButton::clicked, this, &QDialog::reject);
    connect(confirmBtn, &QPushButton::clicked, this, [this]() {
        if (m_selected.x() >= 0) {
            emit cellSelected(m_selected.x(), m_selected.y());
            accept();
        }
    });
}

QPushButton *GridSelectDialog::createCell(int row, int col, bool occupied)
{
    auto *btn = new QPushButton;
    btn->setFixedSize(48, 48);
    btn->setCursor(Qt::PointingHandCursor);

    if (occupied) {
        btn->setText("🌲");
        btn->setObjectName("occupiedCell");
        btn->setEnabled(false);
    } else {
        btn->setText("");
        btn->setObjectName("emptyCell");
        connect(btn, &QPushButton::clicked, this, [this, row, col, btn]() {
            // 取消之前的选中
            for (auto *b : m_cells) {
                if (b->isEnabled() && b->objectName() == "selectedCell")
                    b->setObjectName("emptyCell");
            }
            btn->setObjectName("selectedCell");
            m_selected = QPoint(row, col);
            m_statusLabel->setText(QString("已选: 第%1行 第%2列").arg(row + 1).arg(col + 1));

            // 更新样式
            btn->style()->unpolish(btn);
            btn->style()->polish(btn);
        });
    }

    return btn;
}

#ifndef GRIDSELECTDIALOG_H
#define GRIDSELECTDIALOG_H

#include <QDialog>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>

class GridSelectDialog : public QDialog {
    Q_OBJECT
public:
    explicit GridSelectDialog(int rows = 8, int cols = 8,
                              const QList<QPoint> &occupied = {},
                              QWidget *parent = nullptr);

    QPoint selectedCell() const { return m_selected; }

signals:
    void cellSelected(int row, int col);

private:
    void setupUI();
    QPushButton *createCell(int row, int col, bool occupied);

    int m_rows, m_cols;
    QPoint m_selected{-1, -1};
    QList<QPoint> m_occupied;
    QGridLayout *m_grid = nullptr;
    QList<QPushButton*> m_cells;
    QLabel *m_statusLabel = nullptr;
};

#endif // GRIDSELECTDIALOG_H

#ifndef GRIDSELECTDIALOG_H
#define GRIDSELECTDIALOG_H

#include <QDialog>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>

/**
 * @brief 8×8 网格选择对话框，用于自定义植物种植位置
 *
 * 显示一个 8×8 按钮网格，已被占用的格子和空闲格子用不同颜色标识。
 * 用户点击空闲格子后发出选中信号。
 */
class GridSelectDialog : public QDialog {
    Q_OBJECT
public:
    /**
     * @brief 构造网格选择对话框
     * @param rows 行数（默认 8）
     * @param cols 列数（默认 8）
     * @param occupied 已被占用的坐标列表
     * @param parent 父窗口
     */
    explicit GridSelectDialog(int rows = 8, int cols = 8,
                              const QList<QPoint> &occupied = {},
                              QWidget *parent = nullptr);

    /**
     * @brief 获取用户选中的坐标
     */
    QPoint selectedCell() const { return m_selected; }

signals:
    /** 用户选中了某个格子 */
    void cellSelected(int row, int col);

private:
    void setupUI();
    QPushButton *createCell(int row, int col, bool occupied);

    int m_rows, m_cols;
    QPoint m_selected{-1, -1};
    QList<QPoint> m_occupied;
    QGridLayout *m_grid = nullptr;
    QList<QPushButton*> m_cells;
    QLabel *m_statusLabel = nullptr;
};

#endif // GRIDSELECTDIALOG_H

#include "ui/HistoryWidget.h"
#include <QPainter>
#include <QFont>
#include <QPainterPath>

TimelineItemWidget::TimelineItemWidget(const HistoryEntry &entry, QWidget *parent)
    : QWidget(parent), m_entry(entry)
{
    setFixedHeight(72);
}

void TimelineItemWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    // 背景
    p.fillRect(rect(), QColor("#1E2A1E"));

    // 左侧时间线
    int lineX = 40;
    p.setPen(QPen(QColor("#4CAF50"), 2));
    p.drawLine(lineX, 0, lineX, height());

    // 节点圆点
    QColor dotColor = m_entry.success ? QColor("#4CAF50") : QColor("#F44336");
    p.setBrush(dotColor);
    p.setPen(QPen(QColor("#1E2A1E"), 2));
    p.drawEllipse(QPointF(lineX, height() / 2.0), 6, 6);

    // 右侧内容区
    int textX = 60;
    QString timeStr = m_entry.timestamp.toString("MM-dd hh:mm");
    QFont timeFont("Arial", 9);
    p.setFont(timeFont);
    p.setPen(QColor("#9E9E9E"));
    p.drawText(textX, 20, timeStr);

    QString mainStr = QString("%1  |  %2 / %3 min  |  %4")
                          .arg(m_entry.plantType)
                          .arg(m_entry.actualMinutes)
                          .arg(m_entry.durationMinutes)
                          .arg(m_entry.success ? "成功" : "失败");
    QFont mainFont("Microsoft YaHei", 10, QFont::Bold);
    p.setFont(mainFont);
    p.setPen(QColor("#E0E0E0"));
    p.drawText(textX, 42, mainStr);
}

// ═══════════════════════════════════════════
// HistoryWidget
// ═══════════════════════════════════════════

HistoryWidget::HistoryWidget(QWidget *parent)
    : QWidget(parent)
{
    setupUI();
}

void HistoryWidget::setupUI()
{
    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(0);
    mainLayout->setContentsMargins(0, 0, 0, 0);

    auto *header = new QLabel("时间历程");
    QFont hFont("Microsoft YaHei", 18, QFont::Bold);
    header->setFont(hFont);
    header->setObjectName("pageTitle");
    header->setContentsMargins(24, 24, 24, 0);
    mainLayout->addWidget(header);

    m_scroll = new QScrollArea;
    m_scroll->setWidgetResizable(true);
    m_scroll->setObjectName("historyScroll");

    m_scrollContent = new QWidget;
    m_timelineLayout = new QVBoxLayout(m_scrollContent);
    m_timelineLayout->setSpacing(0);
    m_timelineLayout->setContentsMargins(0, 8, 0, 8);
    m_timelineLayout->addStretch();
    m_scroll->setWidget(m_scrollContent);

    mainLayout->addWidget(m_scroll, 1);
}

void HistoryWidget::setHistory(const QList<HistoryEntry> &entries)
{
    // 清除旧项目
    while (m_timelineLayout->count() > 1) {
        QLayoutItem *item = m_timelineLayout->takeAt(0);
        if (item->widget()) item->widget()->deleteLater();
        delete item;
    }

    for (const auto &entry : entries) {
        auto *itemWidget = new TimelineItemWidget(entry);
        m_timelineLayout->insertWidget(m_timelineLayout->count() - 1, itemWidget);
    }
}

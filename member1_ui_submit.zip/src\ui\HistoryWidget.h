#ifndef HISTORYWIDGET_H
#define HISTORYWIDGET_H

#include <QWidget>
#include <QScrollArea>
#include <QVBoxLayout>
#include <QLabel>
#include <QDateTime>
#include <QList>

/**
 * @brief 历史专注记录条目
 */
struct HistoryEntry {
    QString plantType;
    int durationMinutes = 0;
    int actualMinutes = 0;
    bool success = false;
    QDateTime timestamp;
};

/**
 * @brief 时间轴上的单个历史条目，QPainter 手绘圆点 + 竖线 + 卡片
 */
class TimelineItemWidget : public QWidget {
    Q_OBJECT
public:
    explicit TimelineItemWidget(const HistoryEntry &entry, QWidget *parent = nullptr);
protected:
    void paintEvent(QPaintEvent *event) override;
private:
    HistoryEntry m_entry;
};

/**
 * @brief 历史记录时间轴页面，滚动显示所有专注记录
 *
 * 使用 TimelineItemWidget 按时间倒序排列，
 * 每个条目显示植物类型、计划/实际时长、成功/失败状态和时间戳。
 */
class HistoryWidget : public QWidget {
    Q_OBJECT
public:
    explicit HistoryWidget(QWidget *parent = nullptr);

    /**
     * @brief 设置历史记录列表
     * @param entries 专注记录条目列表
     */
    void setHistory(const QList<HistoryEntry> &entries);

private:
    void setupUI();

    QVBoxLayout *m_timelineLayout = nullptr;
    QScrollArea *m_scroll = nullptr;
    QWidget *m_scrollContent = nullptr;
};

#endif // HISTORYWIDGET_H

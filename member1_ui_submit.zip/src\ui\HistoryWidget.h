#ifndef HISTORYWIDGET_H
#define HISTORYWIDGET_H

#include <QWidget>
#include <QScrollArea>
#include <QVBoxLayout>
#include <QLabel>
#include <QDateTime>
#include <QList>

struct HistoryEntry {
    QString plantType;
    int durationMinutes = 0;
    int actualMinutes = 0;
    bool success = false;
    QDateTime timestamp;
};

class TimelineItemWidget : public QWidget {
    Q_OBJECT
public:
    explicit TimelineItemWidget(const HistoryEntry &entry, QWidget *parent = nullptr);
protected:
    void paintEvent(QPaintEvent *event) override;
private:
    HistoryEntry m_entry;
};

class HistoryWidget : public QWidget {
    Q_OBJECT
public:
    explicit HistoryWidget(QWidget *parent = nullptr);

    void setHistory(const QList<HistoryEntry> &entries);

private:
    void setupUI();

    QVBoxLayout *m_timelineLayout = nullptr;
    QScrollArea *m_scroll = nullptr;
    QWidget *m_scrollContent = nullptr;
};

#endif // HISTORYWIDGET_H

#include "ui/LoginDialog.h"
#include <QFont>
#include <QGraphicsDropShadowEffect>
#include <QTimer>

LoginDialog::LoginDialog(QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle("FocusForest — 登录");
    setFixedSize(420, 480);
    setObjectName("loginDialog");
    setupUI();
}

void LoginDialog::setupUI()
{
    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(40, 30, 40, 30);
    mainLayout->setSpacing(16);

    // Logo 区
    auto *logo = new QLabel("🌳 FocusForest");
    QFont logoFont("Microsoft YaHei", 22, QFont::Bold);
    logo->setFont(logoFont);
    logo->setObjectName("pageTitle");
    logo->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(logo);

    auto *subtitle = new QLabel("专注森林 · 让每一分钟都生根发芽");
    subtitle->setObjectName("hintLabel");
    subtitle->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(subtitle);

    mainLayout->addSpacing(10);

    // 页面切换按钮
    auto *toggleRow = new QHBoxLayout;
    auto *loginTab = new QPushButton("登录");
    loginTab->setObjectName("primaryBtn");
    loginTab->setFixedWidth(140);
    auto *regTab = new QPushButton("注册");
    regTab->setObjectName("secondaryBtn");
    regTab->setFixedWidth(140);
    toggleRow->addStretch();
    toggleRow->addWidget(loginTab);
    toggleRow->addWidget(regTab);
    toggleRow->addStretch();
    mainLayout->addLayout(toggleRow);

    // 堆叠页面
    m_stack = new QStackedWidget;
    m_stack->addWidget(createLoginPage());
    m_stack->addWidget(createRegisterPage());
    mainLayout->addWidget(m_stack);

    // 状态提示
    m_statusLabel = new QLabel;
    m_statusLabel->setObjectName("hintLabel");
    m_statusLabel->setAlignment(Qt::AlignCenter);
    m_statusLabel->setWordWrap(true);
    mainLayout->addWidget(m_statusLabel);

    mainLayout->addStretch();

    connect(loginTab, &QPushButton::clicked, this, [this, loginTab, regTab]() {
        m_stack->setCurrentIndex(0);
        loginTab->setObjectName("primaryBtn");
        regTab->setObjectName("secondaryBtn");
        loginTab->style()->unpolish(loginTab); loginTab->style()->polish(loginTab);
        regTab->style()->unpolish(regTab); regTab->style()->polish(regTab);
        m_statusLabel->clear();
    });

    connect(regTab, &QPushButton::clicked, this, [this, loginTab, regTab]() {
        m_stack->setCurrentIndex(1);
        regTab->setObjectName("primaryBtn");
        loginTab->setObjectName("secondaryBtn");
        loginTab->style()->unpolish(loginTab); loginTab->style()->polish(loginTab);
        regTab->style()->unpolish(regTab); regTab->style()->polish(regTab);
        m_statusLabel->clear();
    });
}

QWidget *LoginDialog::createLoginPage()
{
    auto *page = new QWidget;
    auto *l = new QVBoxLayout(page);
    l->setSpacing(12);
    l->setContentsMargins(0, 8, 0, 0);

    m_loginUser = new QLineEdit;
    m_loginUser->setPlaceholderText("用户名");
    m_loginUser->setMinimumHeight(40);
    l->addWidget(m_loginUser);

    m_loginPass = new QLineEdit;
    m_loginPass->setPlaceholderText("密码");
    m_loginPass->setEchoMode(QLineEdit::Password);
    m_loginPass->setMinimumHeight(40);
    l->addWidget(m_loginPass);

    auto *btn = new QPushButton("登  录");
    btn->setObjectName("primaryBtn");
    btn->setMinimumHeight(44);
    QFont btnFont("Microsoft YaHei", 13);
    btn->setFont(btnFont);
    connect(btn, &QPushButton::clicked, this, &LoginDialog::doLogin);
    l->addWidget(btn);

    return page;
}

QWidget *LoginDialog::createRegisterPage()
{
    auto *page = new QWidget;
    auto *l = new QVBoxLayout(page);
    l->setSpacing(12);
    l->setContentsMargins(0, 8, 0, 0);

    m_regUser = new QLineEdit;
    m_regUser->setPlaceholderText("用户名（3-16位）");
    m_regUser->setMinimumHeight(40);
    l->addWidget(m_regUser);

    m_regPass = new QLineEdit;
    m_regPass->setPlaceholderText("密码（6-32位）");
    m_regPass->setEchoMode(QLineEdit::Password);
    m_regPass->setMinimumHeight(40);
    l->addWidget(m_regPass);

    m_regPass2 = new QLineEdit;
    m_regPass2->setPlaceholderText("确认密码");
    m_regPass2->setEchoMode(QLineEdit::Password);
    m_regPass2->setMinimumHeight(40);
    l->addWidget(m_regPass2);

    auto *btn = new QPushButton("注  册");
    btn->setObjectName("primaryBtn");
    btn->setMinimumHeight(44);
    QFont btnFont("Microsoft YaHei", 13);
    btn->setFont(btnFont);
    connect(btn, &QPushButton::clicked, this, &LoginDialog::doRegister);
    l->addWidget(btn);

    return page;
}

void LoginDialog::doLogin()
{
    QString user = m_loginUser->text().trimmed();
    QString pass = m_loginPass->text();

    if (user.isEmpty() || pass.isEmpty()) {
        m_statusLabel->setText("用户名和密码不能为空");
        return;
    }

    // 临时模拟：任何账号密码都通过（等成员3接入UserManager）
    m_userId = qHash(user) % 10000;
    m_username = user;
    m_statusLabel->setText("登录成功！");
    QTimer::singleShot(500, this, [this]() {
        emit loginSuccess(m_userId, m_username);
        accept();
    });
}

void LoginDialog::doRegister()
{
    QString user = m_regUser->text().trimmed();
    QString pass = m_regPass->text();
    QString pass2 = m_regPass2->text();

    if (user.length() < 3) {
        m_statusLabel->setText("用户名至少3位");
        return;
    }
    if (pass.length() < 6) {
        m_statusLabel->setText("密码至少6位");
        return;
    }
    if (pass != pass2) {
        m_statusLabel->setText("两次密码不一致");
        return;
    }

    m_userId = qHash(user) % 10000;
    m_username = user;
    m_statusLabel->setText("注册成功！");
    QTimer::singleShot(500, this, [this]() {
        emit registerSuccess(m_userId, m_username);
        accept();
    });
}

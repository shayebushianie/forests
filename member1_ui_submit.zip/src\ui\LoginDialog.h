#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H

#include <QDialog>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>

class LoginDialog : public QDialog {
    Q_OBJECT
public:
    explicit LoginDialog(QWidget *parent = nullptr);

    int loggedInUserId() const { return m_userId; }
    QString loggedInUsername() const { return m_username; }

signals:
    void loginSuccess(int userId, const QString &username);
    void registerSuccess(int userId, const QString &username);

private:
    void setupUI();
    QWidget *createLoginPage();
    QWidget *createRegisterPage();
    void doLogin();
    void doRegister();

    QStackedWidget *m_stack = nullptr;
    QLabel *m_statusLabel = nullptr;

    // 登录页
    QLineEdit *m_loginUser = nullptr;
    QLineEdit *m_loginPass = nullptr;

    // 注册页
    QLineEdit *m_regUser = nullptr;
    QLineEdit *m_regPass = nullptr;
    QLineEdit *m_regPass2 = nullptr;

    int m_userId = -1;
    QString m_username;
};

#endif // LOGINDIALOG_H

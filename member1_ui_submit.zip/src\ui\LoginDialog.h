#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H

#include <QDialog>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>

/**
 * @brief 登录/注册模态对话框，支持多账号系统
 *
 * 使用 QStackedWidget 在登录页和注册页之间切换。
 * 登录成功后通过信号通知 MainWindow。
 */
class LoginDialog : public QDialog {
    Q_OBJECT
public:
    explicit LoginDialog(QWidget *parent = nullptr);

    /**
     * @brief 获取当前登录用户 ID
     * @return 用户 ID，未登录返回 -1
     */
    int loggedInUserId() const { return m_userId; }

    /**
     * @brief 获取当前登录用户名
     */
    QString loggedInUsername() const { return m_username; }

signals:
    /** 登录成功 */
    void loginSuccess(int userId, const QString &username);
    /** 注册并登录成功 */
    void registerSuccess(int userId, const QString &username);

private:
    void setupUI();
    QWidget *createLoginPage();
    QWidget *createRegisterPage();
    void doLogin();
    void doRegister();

    QStackedWidget *m_stack = nullptr;
    QLabel *m_statusLabel = nullptr;

    // 登录页
    QLineEdit *m_loginUser = nullptr;
    QLineEdit *m_loginPass = nullptr;

    // 注册页
    QLineEdit *m_regUser = nullptr;
    QLineEdit *m_regPass = nullptr;
    QLineEdit *m_regPass2 = nullptr;

    int m_userId = -1;
    QString m_username;
};

#endif // LOGINDIALOG_H

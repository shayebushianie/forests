#include "ui/MainWindow.h"
#include "ui/GardenCanvas.h"
#include "ui/PlantTimerWidget.h"
#include "ui/QuoteWidget.h"
#include "ui/SettingsDialog.h"
#include "ui/StoreDialog.h"
#include "ui/StatisticsDialog.h"
#include "ui/HistoryWidget.h"
#include "ui/AchievementToast.h"
#include "ui/ViolationWarningWidget.h"
#include "ui/LoginDialog.h"
#include "core/FocusController.h"

#include <QHBoxLayout>
#include <QFont>
#include <QIcon>
#include <QTimer>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle("FocusForest — 专注森林");
    resize(960, 680);
    setMinimumSize(800, 600);

    setupUI();
    setupDrawer();
    setupPages();
    setupConnections();

    m_drawer->setCurrentRow(0);

    // 启动时弹出登录
    QTimer::singleShot(300, this, &MainWindow::showLogin);
}

MainWindow::~MainWindow() {}

void MainWindow::setController(FocusController *ctrl)
{
    m_controller = ctrl;
    setupConnections();
}

void MainWindow::showAchievement(const QString &name, const QString &desc)
{
    if (m_achieveToast) {
        m_achieveToast->showAchievement(name, desc);
    }
}

void MainWindow::showLogin()
{
    if (!m_loginDialog) {
        m_loginDialog = new LoginDialog(this);
        connect(m_loginDialog, &LoginDialog::loginSuccess, this, [this](int uid, const QString &user) {
            setWindowTitle(QString("FocusForest — 专注森林 | %1").arg(user));
        });
        connect(m_loginDialog, &LoginDialog::registerSuccess, this, [this](int uid, const QString &user) {
            setWindowTitle(QString("FocusForest — 专注森林 | %1").arg(user));
        });
    }
    m_loginDialog->exec();
}

void MainWindow::onViolationDetected(const QString &processName)
{
    if (!m_violationWarning) {
        m_violationWarning = new ViolationWarningWidget(nullptr);
        connect(m_violationWarning, &ViolationWarningWidget::warningTimeout, this, [this]() {
            if (m_controller) m_controller->abandon();
        });
        connect(m_violationWarning, &ViolationWarningWidget::warningDismissed, this, &MainWindow::onViolationDismissed);
    }
    m_violationWarning->show(processName);
}

void MainWindow::onViolationDismissed()
{
    // 用户切回，免罚
}

void MainWindow::setupUI()
{
    m_centralWidget = new QWidget(this);
    setCentralWidget(m_centralWidget);

    auto *mainLayout = new QHBoxLayout(m_centralWidget);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    m_drawer = new QListWidget;
    m_drawer->setFixedWidth(180);
    m_drawer->setObjectName("drawerNav");
    m_drawer->setIconSize(QSize(24, 24));

    m_pages = new QStackedWidget;
    m_pages->setObjectName("pageContainer");

    m_coinLabel = new QLabel;
    m_coinLabel->setObjectName("coinLabel");
    m_coinLabel->setAlignment(Qt::AlignCenter);

    auto *rightLayout = new QVBoxLayout;
    rightLayout->setContentsMargins(0, 0, 0, 0);
    rightLayout->setSpacing(0);
    rightLayout->addWidget(m_coinLabel);
    rightLayout->addWidget(m_pages, 1);

    mainLayout->addWidget(m_drawer);
    mainLayout->addLayout(rightLayout, 1);
}

void MainWindow::setupDrawer()
{
    struct NavItem { QString icon; QString text; int page; };
    QList<NavItem> items = {
        {":/icons/forest.png",   "专注森林", PAGE_HOME},
        {":/icons/settings.png", "设置",     PAGE_SETTINGS},
        {":/icons/store.png",    "金币商城", PAGE_STORE},
        {":/icons/stats.png",    "数据统计", PAGE_STATS},
        {":/icons/history.png",  "时间历程", PAGE_HISTORY},
    };

    QFont font("Microsoft YaHei", 11);
    for (const auto &item : items) {
        auto *listItem = new QListWidgetItem(QIcon(item.icon), item.text);
        listItem->setFont(font);
        listItem->setSizeHint(QSize(0, 48));
        listItem->setData(Qt::UserRole, item.page);
        m_drawer->addItem(listItem);
    }

    connect(m_drawer, &QListWidget::currentRowChanged, this, [this](int row) {
        if (row < 0 || row >= m_drawer->count()) return;
        int page = m_drawer->item(row)->data(Qt::UserRole).toInt();
        m_pages->setCurrentIndex(page);
    });
}

void MainWindow::setupPages()
{
    m_gardenCanvas = new GardenCanvas;
    m_plantTimer = new PlantTimerWidget;
    m_quoteWidget = new QuoteWidget;

    // 首页：誓言输入+预设+计时圆环+语录+森林画布
    auto *homePage = new QWidget;
    auto *homeLayout = new QVBoxLayout(homePage);
    homeLayout->setSpacing(4);
    homeLayout->setContentsMargins(12, 8, 12, 8);
    homeLayout->addWidget(m_plantTimer, 1);
    homeLayout->addWidget(m_quoteWidget);
    homeLayout->addWidget(m_gardenCanvas, 2);
    m_pages->addWidget(homePage);

    m_settingsDialog = new SettingsDialog;
    m_pages->addWidget(m_settingsDialog);

    m_storeDialog = new StoreDialog;
    m_pages->addWidget(m_storeDialog);

    m_statisticsDialog = new StatisticsDialog;
    m_pages->addWidget(m_statisticsDialog);

    m_historyWidget = new HistoryWidget;
    m_pages->addWidget(m_historyWidget);

    m_achieveToast = new AchievementToast(this);
}

void MainWindow::setupConnections()
{
    // PlantTimer → Controller
    connect(m_plantTimer, &PlantTimerWidget::startRequested, this, [this](int minutes) {
        if (m_controller) m_controller->startFocus(-1, minutes);
        m_quoteWidget->startCycling();
    });
    connect(m_plantTimer, &PlantTimerWidget::pauseRequested, this, [this]() {
        if (m_controller) m_controller->pause();
    });
    connect(m_plantTimer, &PlantTimerWidget::resumeRequested, this, [this]() {
        if (m_controller) m_controller->resume();
    });
    connect(m_plantTimer, &PlantTimerWidget::abandonRequested, this, [this]() {
        if (m_controller) m_controller->abandon();
        m_quoteWidget->stopCycling();
    });

    // Settings → Controller
    connect(m_settingsDialog, &SettingsDialog::addBlacklistRequested, this, [this](const QString &p) {
        if (m_controller) m_controller->addBlacklist(p);
    });
    connect(m_settingsDialog, &SettingsDialog::removeBlacklistRequested, this, [this](const QString &p) {
        if (m_controller) m_controller->removeBlacklist(p);
    });
    connect(m_settingsDialog, &SettingsDialog::strictModeChanged, this, [this](bool strict) {
        if (m_controller) m_controller->setStrictMode(strict);
    });

    // Store → Controller
    connect(m_storeDialog, &StoreDialog::purchaseRequested, this, [this](int plantId) {
        if (m_controller) m_controller->unlockPlant(plantId);
    });

    if (!m_controller) return;

    // Controller → UI
    connect(m_controller, &FocusController::stateChanged, this, [this](int state) {
        auto s = static_cast<FocusController::State>(state);
        switch (s) {
        case FocusController::State::FOCUSING:
            m_plantTimer->setRunning(true);
            break;
        case FocusController::State::PAUSED:
            m_plantTimer->setRunning(false);
            break;
        case FocusController::State::IDLE:
        case FocusController::State::SUCCESS:
        case FocusController::State::FAILED:
            m_plantTimer->reset();
            m_quoteWidget->stopCycling();
            break;
        }
    });

    connect(m_controller, &FocusController::tick, m_plantTimer, &PlantTimerWidget::onTick);

    connect(m_controller, &FocusController::plantGrown, m_gardenCanvas, &GardenCanvas::onPlantGrown);

    connect(m_controller, &FocusController::sessionFinished, this, [this](bool success, int coins) {
        m_quoteWidget->stopCycling();
        if (success) {
            showAchievement("专注完成！", QString("获得 %1 金币").arg(coins));
        }
    });

    connect(m_controller, &FocusController::coinBalanceChanged, this, [this](int balance) {
        m_coinLabel->setText(QString("金币: %1").arg(balance));
    });

    connect(m_controller, &FocusController::achievementEarned,
            this, &MainWindow::showAchievement);

    connect(m_controller, &FocusController::plantUnlocked, this, [this](int plantId) {
        showAchievement("解锁新植物！", "快去森林里看看吧");
    });
}

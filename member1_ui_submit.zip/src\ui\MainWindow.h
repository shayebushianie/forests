#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QListWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QPropertyAnimation>

class FocusController;
class GardenCanvas;
class PlantTimerWidget;
class QuoteWidget;
class SettingsDialog;
class StoreDialog;
class StatisticsDialog;
class HistoryWidget;
class AchievementToast;
class ViolationWarningWidget;
class LoginDialog;

/**
 * @brief 应用程序主窗口，采用抽屉式导航 + QStackedWidget 多页面切换
 *
 * 页面包括：首页（专注计时）、设置（黑白名单）、商城、统计、历史记录。
 * 通过 Qt 信号槽与 FocusController 双向通信，实现 MVC 架构的 View 层。
 */
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    /**
     * @brief 构造主窗口，初始化 UI 布局和抽屉导航
     */
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

    /**
     * @brief 注入 FocusController 并连接信号槽
     * @param ctrl 控制器指针，由 main.cpp 创建
     */
    void setController(FocusController *ctrl);

    /**
     * @brief 弹出成就解锁 Toast 动画
     * @param name 成就名称
     * @param desc 成就描述
     */
    void showAchievement(const QString &name, const QString &desc);

    /**
     * @brief 以模态方式显示登录/注册对话框
     */
    void showLogin();

public slots:
    /**
     * @brief 接收到违规信号时显示 10 秒全屏警告
     * @param processName 被检测到的违规进程名
     */
    void onViolationDetected(const QString &processName);

    /**
     * @brief 违规警告被用户手动关闭或切回时调用
     */
    void onViolationDismissed();

private:
    void setupUI();
    void setupDrawer();
    void setupPages();
    void setupConnections();

    FocusController *m_controller = nullptr;

    QWidget *m_centralWidget = nullptr;
    QListWidget *m_drawer = nullptr;
    QStackedWidget *m_pages = nullptr;
    QLabel *m_coinLabel = nullptr;

    PlantTimerWidget *m_plantTimer = nullptr;
    QuoteWidget *m_quoteWidget = nullptr;
    GardenCanvas *m_gardenCanvas = nullptr;
    SettingsDialog *m_settingsDialog = nullptr;
    StoreDialog *m_storeDialog = nullptr;
    StatisticsDialog *m_statisticsDialog = nullptr;
    HistoryWidget *m_historyWidget = nullptr;
    AchievementToast *m_achieveToast = nullptr;
    ViolationWarningWidget *m_violationWarning = nullptr;
    LoginDialog *m_loginDialog = nullptr;

    static constexpr int PAGE_HOME = 0;
    static constexpr int PAGE_SETTINGS = 1;
    static constexpr int PAGE_STORE = 2;
    static constexpr int PAGE_STATS = 3;
    static constexpr int PAGE_HISTORY = 4;
};

#endif // MAINWINDOW_H

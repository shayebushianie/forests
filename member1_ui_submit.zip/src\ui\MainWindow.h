#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QListWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QPropertyAnimation>

class FocusController;
class GardenCanvas;
class PlantTimerWidget;
class QuoteWidget;
class SettingsDialog;
class StoreDialog;
class StatisticsDialog;
class HistoryWidget;
class AchievementToast;
class ViolationWarningWidget;
class LoginDialog;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

    void setController(FocusController *ctrl);
    void showAchievement(const QString &name, const QString &desc);
    void showLogin();

public slots:
    void onViolationDetected(const QString &processName);
    void onViolationDismissed();

private:
    void setupUI();
    void setupDrawer();
    void setupPages();
    void setupConnections();

    FocusController *m_controller = nullptr;

    QWidget *m_centralWidget = nullptr;
    QListWidget *m_drawer = nullptr;
    QStackedWidget *m_pages = nullptr;
    QLabel *m_coinLabel = nullptr;

    PlantTimerWidget *m_plantTimer = nullptr;
    QuoteWidget *m_quoteWidget = nullptr;
    GardenCanvas *m_gardenCanvas = nullptr;
    SettingsDialog *m_settingsDialog = nullptr;
    StoreDialog *m_storeDialog = nullptr;
    StatisticsDialog *m_statisticsDialog = nullptr;
    HistoryWidget *m_historyWidget = nullptr;
    AchievementToast *m_achieveToast = nullptr;
    ViolationWarningWidget *m_violationWarning = nullptr;
    LoginDialog *m_loginDialog = nullptr;

    static constexpr int PAGE_HOME = 0;
    static constexpr int PAGE_SETTINGS = 1;
    static constexpr int PAGE_STORE = 2;
    static constexpr int PAGE_STATS = 3;
    static constexpr int PAGE_HISTORY = 4;
};

#endif // MAINWINDOW_H

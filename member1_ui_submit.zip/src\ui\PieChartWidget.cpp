#include "ui/PieChartWidget.h"
#include <QPainter>
#include <QPainterPath>
#include <QFont>
#include <QtMath>

const QList<QColor> PieChartWidget::kPalette = {
    QColor("#4CAF50"), QColor("#2196F3"), QColor("#FF9800"),
    QColor("#E91E63"), QColor("#9C27B0"), QColor("#00BCD4"),
    QColor("#FF5722"), QColor("#607D8B"),
};

PieChartWidget::PieChartWidget(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(300, 240);
}

void PieChartWidget::setData(const QList<PieSlice> &slices)
{
    m_slices = slices;
    m_total = 0;
    for (const auto &s : slices) m_total += s.value;
    update();
}

void PieChartWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    p.fillRect(rect(), QColor("#1E2A1E"));

    if (m_slices.isEmpty()) {
        p.setPen(QColor("#607D8B"));
        p.setFont(QFont("Microsoft YaHei", 14));
        p.drawText(rect(), Qt::AlignCenter, "暂无数据");
        return;
    }

    // 左右分区域
    qreal chartW = qMin(width() * 0.6, height() * 0.9);
    qreal chartH = chartW;
    qreal chartX = (width() * 0.6 - chartW) / 2;
    qreal chartY = (height() - chartH) / 2;
    m_chartRect = QRectF(chartX, chartY, chartW, chartH);

    m_legendRect = QRectF(width() * 0.62, chartY, width() * 0.36, chartH);

    drawDonut(p);

    // 图例
    qreal lx = m_legendRect.left();
    qreal ly = m_legendRect.top();
    QFont legendFont("Microsoft YaHei", 10);
    p.setFont(legendFont);

    for (int i = 0; i < m_slices.size() && i < kPalette.size(); i++) {
        const auto &slice = m_slices[i];
        QColor color = slice.color.isValid() ? slice.color : kPalette[i];

        p.setBrush(color);
        p.setPen(Qt::NoPen);
        p.drawRect(QRectF(lx, ly + i * 28 + 2, 14, 14));

        p.setPen(QColor("#C0C0C0"));
        double pct = m_total > 0 ? 100.0 * slice.value / m_total : 0;
        QString text = QString("%1  %2h (%3%)")
                           .arg(slice.label)
                           .arg(QString::number(slice.value / 60.0, 'f', 1))
                           .arg(QString::number(pct, 'f', 1));
        p.drawText(QPointF(lx + 20, ly + i * 28 + 14), text);
    }
}

void PieChartWidget::drawDonut(QPainter &p)
{
    if (m_total <= 0) return;

    QRectF r = m_chartRect;
    qreal innerRatio = 0.55;  // 甜甜圈内径比例
    QRectF inner = r.adjusted(r.width() * (1 - innerRatio) / 2,
                              r.height() * (1 - innerRatio) / 2,
                              -r.width() * (1 - innerRatio) / 2,
                              -r.height() * (1 - innerRatio) / 2);

    double startAngle = 90;  // 从顶部开始
    for (int i = 0; i < m_slices.size() && i < kPalette.size(); i++) {
        double spanAngle = 360.0 * m_slices[i].value / m_total;

        QColor color = m_slices[i].color.isValid() ? m_slices[i].color : kPalette[i];
        p.setBrush(color);
        p.setPen(QPen(QColor("#1E2A1E"), 3));

        QPainterPath path;
        path.arcMoveTo(r, startAngle);
        path.arcTo(r, startAngle, spanAngle);
        path.arcTo(inner, startAngle + spanAngle, -spanAngle);
        path.closeSubpath();
        p.drawPath(path);

        startAngle += spanAngle;
    }

    // 中心文字
    p.setPen(QColor("#E0E0E0"));
    QFont f("Arial", (int)(r.width() * 0.08), QFont::Bold);
    p.setFont(f);
    int totalHours = m_total / 60;
    p.drawText(inner, Qt::AlignCenter,
               QString("%1h\n总时长").arg(totalHours));
}

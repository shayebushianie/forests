#ifndef PIECHARTWIDGET_H
#define PIECHARTWIDGET_H

#include <QWidget>
#include <QMap>
#include <QString>
#include <QColor>

struct PieSlice {
    QString label;
    int value = 0;
    QColor color;
};

class PieChartWidget : public QWidget {
    Q_OBJECT
public:
    explicit PieChartWidget(QWidget *parent = nullptr);

    void setData(const QList<PieSlice> &slices);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    void drawDonut(QPainter &p);

    QList<PieSlice> m_slices;
    int m_total = 0;
    QRectF m_chartRect;
    QRectF m_legendRect;

    static const QList<QColor> kPalette;
};

#endif // PIECHARTWIDGET_H

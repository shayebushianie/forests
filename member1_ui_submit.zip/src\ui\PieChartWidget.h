#ifndef PIECHARTWIDGET_H
#define PIECHARTWIDGET_H

#include <QWidget>
#include <QMap>
#include <QString>
#include <QColor>

/**
 * @brief 饼图数据切片
 */
struct PieSlice {
    QString label;
    int value = 0;
    QColor color;
};

/**
 * @brief QPainter 手绘甜甜圈饼图组件
 *
 * 绘制环形饼图 + 右侧图例，无第三方图表库依赖。
 * 内置 8 色调色板自动分配颜色。
 */
class PieChartWidget : public QWidget {
    Q_OBJECT
public:
    explicit PieChartWidget(QWidget *parent = nullptr);

    /**
     * @brief 设置饼图数据并触发重绘
     * @param slices 各切片数据（标签、数值、颜色）
     */
    void setData(const QList<PieSlice> &slices);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    void drawDonut(QPainter &p);

    QList<PieSlice> m_slices;
    int m_total = 0;
    QRectF m_chartRect;
    QRectF m_legendRect;

    static const QList<QColor> kPalette;
};

#endif // PIECHARTWIDGET_H

#include "ui/PlantTimerWidget.h"
#include "ui/TimerRing.h"
#include "ui/PresetSelector.h"
#include <QFont>
#include <QStackedWidget>

PlantTimerWidget::PlantTimerWidget(QWidget *parent)
    : QWidget(parent)
{
    setupUI();
}

void PlantTimerWidget::setupUI()
{
    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(12);
    mainLayout->setContentsMargins(16, 8, 16, 8);

    // 树梢誓言输入
    auto *declLayout = new QHBoxLayout;
    auto *declIcon = new QLabel("🌱");
    declIcon->setStyleSheet("font-size: 18px;");
    m_declarationInput = new QLineEdit;
    m_declarationInput->setPlaceholderText("写下你的目标宣言...");
    m_declarationInput->setMinimumHeight(36);
    declLayout->addWidget(declIcon);
    declLayout->addWidget(m_declarationInput, 1);
    mainLayout->addLayout(declLayout);

    connect(m_declarationInput, &QLineEdit::editingFinished, this, [this]() {
        emit declarationChanged(m_declarationInput->text());
    });

    // 快捷预设
    auto *presetSel = new PresetSelector;
    connect(presetSel, &PresetSelector::presetSelected, this, &PlantTimerWidget::onPresetSelected);
    mainLayout->addWidget(presetSel);

    // 计时圆环
    m_timerRing = new TimerRing;
    m_timerRing->setMinimumHeight(240);
    mainLayout->addWidget(m_timerRing, 1);

    // 控制按钮行
    auto *btnRow = new QHBoxLayout;
    btnRow->setSpacing(12);

    m_startBtn = new QPushButton("🌳 开始专注");
    m_startBtn->setObjectName("primaryBtn");
    m_startBtn->setMinimumHeight(42);
    QFont btnFont("Microsoft YaHei", 12, QFont::Bold);
    m_startBtn->setFont(btnFont);

    m_pauseBtn = new QPushButton("⏸ 暂停");
    m_pauseBtn->setObjectName("secondaryBtn");
    m_pauseBtn->setMinimumHeight(42);
    m_pauseBtn->setFont(QFont("Microsoft YaHei", 11));

    m_abandonBtn = new QPushButton("✕ 放弃");
    m_abandonBtn->setObjectName("dangerBtn");
    m_abandonBtn->setMinimumHeight(42);

    btnRow->addWidget(m_startBtn);
    btnRow->addWidget(m_pauseBtn);
    btnRow->addWidget(m_abandonBtn);
    btnRow->addStretch();
    mainLayout->addLayout(btnRow);

    // 按钮逻辑
    connect(m_startBtn, &QPushButton::clicked, this, [this]() {
        emit startRequested(m_timerRing->durationMinutes());
        updateStateDisplay(true);
    });
    connect(m_pauseBtn, &QPushButton::clicked, this, [this]() {
        if (!m_running) return;
        if (m_pauseBtn->text().contains("暂停")) {
            m_pauseBtn->setText("▶ 继续");
            emit pauseRequested();
        } else {
            m_pauseBtn->setText("⏸ 暂停");
            emit resumeRequested();
        }
    });
    connect(m_abandonBtn, &QPushButton::clicked, this, [this]() {
        emit abandonRequested();
        updateStateDisplay(false);
        m_timerRing->reset();
    });

    updateStateDisplay(false);
}

QString PlantTimerWidget::declaration() const
{
    return m_declarationInput->text().trimmed();
}

int PlantTimerWidget::durationMinutes() const
{
    return m_timerRing ? m_timerRing->durationMinutes() : 25;
}

void PlantTimerWidget::setRunning(bool running)
{
    m_running = running;
    m_timerRing->setRunning(running);
    updateStateDisplay(running);
}

void PlantTimerWidget::reset()
{
    m_running = false;
    m_timerRing->reset();
    updateStateDisplay(false);
}

void PlantTimerWidget::onTick(int remainingSeconds, int totalSeconds)
{
    m_timerRing->onTick(remainingSeconds, totalSeconds);
}

void PlantTimerWidget::onPresetSelected(int minutes)
{
    m_timerRing->setDuration(minutes);
}

void PlantTimerWidget::updateStateDisplay(bool running)
{
    m_startBtn->setVisible(!running);
    m_pauseBtn->setVisible(running);
    m_abandonBtn->setVisible(running);
    m_declarationInput->setReadOnly(running);
    if (running) {
        m_pauseBtn->setText("⏸ 暂停");
    }
}

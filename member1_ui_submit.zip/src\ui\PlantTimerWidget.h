#ifndef PLANTTIMERWIDGET_H
#define PLANTTIMERWIDGET_H

#include <QWidget>
#include <QLineEdit>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPainter>

class TimerRing;

class PlantTimerWidget : public QWidget {
    Q_OBJECT
public:
    explicit PlantTimerWidget(QWidget *parent = nullptr);

    QString declaration() const;
    int durationMinutes() const;

    void setRunning(bool running);
    void reset();

signals:
    void startRequested(int minutes);
    void pauseRequested();
    void resumeRequested();
    void abandonRequested();
    void declarationChanged(const QString &text);

public slots:
    void onTick(int remainingSeconds, int totalSeconds);
    void onPresetSelected(int minutes);

private:
    void setupUI();
    void updateStateDisplay(bool running);

    TimerRing *m_timerRing = nullptr;

    QLineEdit *m_declarationInput = nullptr;
    QPushButton *m_startBtn = nullptr;
    QPushButton *m_pauseBtn = nullptr;
    QPushButton *m_abandonBtn = nullptr;

    bool m_running = false;
};

#endif // PLANTTIMERWIDGET_H

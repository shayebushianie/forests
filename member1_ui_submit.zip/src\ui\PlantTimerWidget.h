#ifndef PLANTTIMERWIDGET_H
#define PLANTTIMERWIDGET_H

#include <QWidget>
#include <QLineEdit>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPainter>

class TimerRing;

/**
 * @brief 首页专注计时面板，集成宣言输入、预设选择、圆环计时与控制按钮
 *
 * 包含 TimerRing 圆环组件和 PresetSelector 预设选择器，
 * 是用户发起专注会话的核心交互入口。
 */
class PlantTimerWidget : public QWidget {
    Q_OBJECT
public:
    explicit PlantTimerWidget(QWidget *parent = nullptr);

    /**
     * @brief 获取用户输入的专注宣言文本
     * @return 宣言字符串
     */
    QString declaration() const;

    /**
     * @brief 获取当前圆环设定的专注时长
     * @return 时长（分钟）
     */
    int durationMinutes() const;

    /**
     * @brief 切换运行/停止状态的 UI 外观
     * @param running true 表示正在专注中
     */
    void setRunning(bool running);

    /**
     * @brief 重置圆环到默认时长 25 分钟
     */
    void reset();

signals:
    /** 用户点击开始按钮，参数为设定分钟数 */
    void startRequested(int minutes);
    /** 用户点击暂停按钮 */
    void pauseRequested();
    /** 用户点击继续按钮 */
    void resumeRequested();
    /** 用户点击放弃按钮 */
    void abandonRequested();
    /** 宣言输入框内容变化 */
    void declarationChanged(const QString &text);

public slots:
    /**
     * @brief 接收控制器每秒 tick 信号，更新圆环进度
     * @param remainingSeconds 剩余秒数
     * @param totalSeconds 总秒数
     */
    void onTick(int remainingSeconds, int totalSeconds);

    /**
     * @brief 接收预设选择结果，更新圆环时长
     * @param minutes 预设分钟数
     */
    void onPresetSelected(int minutes);

private:
    void setupUI();
    void updateStateDisplay(bool running);

    TimerRing *m_timerRing = nullptr;

    QLineEdit *m_declarationInput = nullptr;
    QPushButton *m_startBtn = nullptr;
    QPushButton *m_pauseBtn = nullptr;
    QPushButton *m_abandonBtn = nullptr;

    bool m_running = false;
};

#endif // PLANTTIMERWIDGET_H

#include "ui/PresetSelector.h"
#include <QFont>
#include <QGraphicsDropShadowEffect>

PresetCard::PresetCard(const PresetData &data, QWidget *parent)
    : QFrame(parent), m_data(data)
{
    setObjectName("presetCard");
    setFixedSize(150, 130);
    setCursor(Qt::PointingHandCursor);

    auto *l = new QVBoxLayout(this);
    l->setSpacing(4);
    l->setContentsMargins(12, 16, 12, 12);

    auto *emoji = new QLabel(data.emoji);
    emoji->setAlignment(Qt::AlignCenter);
    emoji->setStyleSheet("font-size: 28px;");

    auto *nameLabel = new QLabel(data.name);
    nameLabel->setObjectName("presetName");
    nameLabel->setAlignment(Qt::AlignCenter);

    auto *timeLabel = new QLabel(QString("%1 分钟").arg(data.minutes));
    timeLabel->setObjectName("presetTime");
    timeLabel->setAlignment(Qt::AlignCenter);

    auto *descLabel = new QLabel(data.description);
    descLabel->setObjectName("presetDesc");
    descLabel->setAlignment(Qt::AlignCenter);
    descLabel->setWordWrap(true);

    l->addWidget(emoji);
    l->addWidget(nameLabel);
    l->addWidget(timeLabel);
    l->addWidget(descLabel);
}

void PresetCard::mousePressEvent(QMouseEvent *)
{
    emit clicked(m_data.minutes);
}

void PresetCard::enterEvent(QEnterEvent *)
{
    setStyleSheet("QFrame#presetCard { border: 2px solid #4CAF50; background-color: #2A3A2A; }");
}

void PresetCard::leaveEvent(QEvent *)
{
    setStyleSheet("");
}

// ═══════════════════════════════════════════
PresetSelector::PresetSelector(QWidget *parent)
    : QWidget(parent)
{
    setupUI();
}

void PresetSelector::setupUI()
{
    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(8);
    mainLayout->setContentsMargins(0, 0, 0, 0);

    auto *title = new QLabel("快捷预设");
    title->setObjectName("sectionTitle");
    title->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(title);

    m_cardRow = new QHBoxLayout;
    m_cardRow->setSpacing(12);

    // 3 组出厂预设
    QList<PresetData> presets = {
        {"番茄专注", 25, "经典25分钟", "🍅"},
        {"深度学习", 50, "长时间沉浸", "📚"},
        {"快速休息", 10, "短暂充电", "☕"},
    };

    for (const auto &p : presets) {
        auto *card = new PresetCard(p);
        connect(card, &PresetCard::clicked, this, &PresetSelector::presetSelected);
        m_cardRow->addWidget(card);
    }

    m_cardRow->addStretch();
    mainLayout->addLayout(m_cardRow);
}

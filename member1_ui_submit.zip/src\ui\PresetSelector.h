#ifndef PRESETSELECTOR_H
#define PRESETSELECTOR_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFrame>

struct PresetData {
    QString name;
    int minutes;
    QString description;
    QString emoji;
};

class PresetCard : public QFrame {
    Q_OBJECT
public:
    PresetCard(const PresetData &data, QWidget *parent = nullptr);
signals:
    void clicked(int minutes);
protected:
    void mousePressEvent(QMouseEvent *event) override;
    void enterEvent(QEnterEvent *event) override;
    void leaveEvent(QEvent *event) override;
private:
    PresetData m_data;
};

class PresetSelector : public QWidget {
    Q_OBJECT
public:
    explicit PresetSelector(QWidget *parent = nullptr);

signals:
    void presetSelected(int minutes);

private:
    void setupUI();
    QHBoxLayout *m_cardRow = nullptr;
};

#endif // PRESETSELECTOR_H

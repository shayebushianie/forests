#ifndef PRESETSELECTOR_H
#define PRESETSELECTOR_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFrame>

/**
 * @brief 快捷预设数据结构
 */
struct PresetData {
    QString name;
    int minutes;
    QString description;
    QString emoji;
};

/**
 * @brief 单个预设卡片，悬停高亮，点击触发
 */
class PresetCard : public QFrame {
    Q_OBJECT
public:
    PresetCard(const PresetData &data, QWidget *parent = nullptr);
signals:
    /** 点击后发出对应的分钟数 */
    void clicked(int minutes);
protected:
    void mousePressEvent(QMouseEvent *event) override;
    void enterEvent(QEnterEvent *event) override;
    void leaveEvent(QEvent *event) override;
private:
    PresetData m_data;
};

/**
 * @brief 快捷预设选择器，水平排列 3 张预设卡片（25/45/90 分钟）
 */
class PresetSelector : public QWidget {
    Q_OBJECT
public:
    explicit PresetSelector(QWidget *parent = nullptr);

signals:
    /** 用户点选了某个预设 */
    void presetSelected(int minutes);

private:
    void setupUI();
    QHBoxLayout *m_cardRow = nullptr;
};

#endif // PRESETSELECTOR_H

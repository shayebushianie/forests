#include "ui/QuoteWidget.h"
#include <QFont>
#include <QRandomGenerator>

const QStringList QuoteWidget::kQuotes = {
    "种一棵树最好的时间是十年前，其次是现在。",
    "专注是通往卓越的唯一道路。",
    "每一个番茄钟，都是在为未来的森林播种。",
    "你以为的极限，只是别人的起点。",
    "不要让明天的你，讨厌今天不努力的自己。",
    "成功不是将来才有的，而是从决定去做的那一刻开始。",
    "你所浪费的今天，是昨天死去的人奢望的明天。",
    "自律给我自由。",
    "优于别人并不高贵，真正的高贵是优于过去的自己。",
    "人生没有白走的路，每一步都算数。",
    "当你停下来休息时，别忘了别人还在奔跑。",
    "宝剑锋从磨砺出，梅花香自苦寒来。",
    "千里之行，始于足下。",
    "不积跬步，无以至千里；不积小流，无以成江海。",
    "天行健，君子以自强不息。",
    "业精于勤荒于嬉，行成于思毁于随。",
};

QuoteWidget::QuoteWidget(QWidget *parent)
    : QWidget(parent)
{
    auto *l = new QVBoxLayout(this);
    l->setContentsMargins(0, 0, 0, 0);

    m_fadeEffect = new QGraphicsOpacityEffect(this);
    m_fadeEffect->setOpacity(1.0);
    setGraphicsEffect(m_fadeEffect);

    m_quoteLabel = new QLabel;
    m_quoteLabel->setObjectName("quoteLabel");
    m_quoteLabel->setAlignment(Qt::AlignCenter);
    m_quoteLabel->setWordWrap(true);
    QFont f("Microsoft YaHei", 12);
    f.setItalic(true);
    m_quoteLabel->setFont(f);
    l->addWidget(m_quoteLabel);

    m_cycleTimer = new QTimer(this);
    m_cycleTimer->setInterval(8000);
    connect(m_cycleTimer, &QTimer::timeout, this, &QuoteWidget::nextQuote);

    setVisible(false);
}

void QuoteWidget::startCycling()
{
    m_currentIndex = QRandomGenerator::global()->bounded(kQuotes.size());
    m_quoteLabel->setText(kQuotes[m_currentIndex]);
    setVisible(true);
    m_cycleTimer->start();
}

void QuoteWidget::stopCycling()
{
    m_cycleTimer->stop();
    setVisible(false);
}

void QuoteWidget::nextQuote()
{
    m_currentIndex = (m_currentIndex + 1) % kQuotes.size();
    fadeTo(kQuotes[m_currentIndex]);
}

void QuoteWidget::fadeTo(const QString &text)
{
    auto *anim = new QPropertyAnimation(m_fadeEffect, "opacity", this);
    anim->setDuration(400);
    anim->setStartValue(1.0);
    anim->setEndValue(0.0);
    connect(anim, &QPropertyAnimation::finished, this, [this, text, anim]() {
        m_quoteLabel->setText(text);
        auto *fadeIn = new QPropertyAnimation(m_fadeEffect, "opacity", this);
        fadeIn->setDuration(400);
        fadeIn->setStartValue(0.0);
        fadeIn->setEndValue(1.0);
        fadeIn->start(QAbstractAnimation::DeleteWhenStopped);
    });
    anim->start(QAbstractAnimation::DeleteWhenStopped);
}

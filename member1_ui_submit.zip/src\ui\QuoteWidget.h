#ifndef QUOTEWIDGET_H
#define QUOTEWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QTimer>
#include <QVBoxLayout>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>

class QuoteWidget : public QWidget {
    Q_OBJECT
public:
    explicit QuoteWidget(QWidget *parent = nullptr);

    void startCycling();   // 专注开始时调用
    void stopCycling();    // 专注结束时调用

private:
    void nextQuote();
    void fadeTo(const QString &text);

    QLabel *m_quoteLabel = nullptr;
    QTimer *m_cycleTimer = nullptr;
    QGraphicsOpacityEffect *m_fadeEffect = nullptr;
    int m_currentIndex = 0;

    static const QStringList kQuotes;
};

#endif // QUOTEWIDGET_H

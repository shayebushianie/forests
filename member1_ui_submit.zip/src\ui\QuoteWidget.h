#ifndef QUOTEWIDGET_H
#define QUOTEWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QTimer>
#include <QVBoxLayout>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>

/**
 * @brief 专注过程中轮播显示自勉语录的组件
 *
 * 内置 16 条中文名言，通过 QPropertyAnimation 实现淡入淡出切换效果。
 */
class QuoteWidget : public QWidget {
    Q_OBJECT
public:
    explicit QuoteWidget(QWidget *parent = nullptr);

    /**
     * @brief 开始定时轮播语录（专注开始时调用）
     */
    void startCycling();

    /**
     * @brief 停止轮播（专注结束时调用）
     */
    void stopCycling();

private:
    void nextQuote();
    void fadeTo(const QString &text);

    QLabel *m_quoteLabel = nullptr;
    QTimer *m_cycleTimer = nullptr;
    QGraphicsOpacityEffect *m_fadeEffect = nullptr;
    int m_currentIndex = 0;

    static const QStringList kQuotes;
};

#endif // QUOTEWIDGET_H

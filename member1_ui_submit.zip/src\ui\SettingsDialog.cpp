#include "ui/SettingsDialog.h"
#include <QMessageBox>

SettingsDialog::SettingsDialog(QWidget *parent)
    : QWidget(parent)
{
    setupUI();
}

void SettingsDialog::setupUI()
{
    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(16);
    mainLayout->setContentsMargins(24, 24, 24, 24);

    // ── 专注模式 ──
    auto *modeGroup = new QGroupBox("专注模式");
    auto *modeLayout = new QVBoxLayout(modeGroup);

    m_strictModeBox = new QCheckBox("严格模式（切到黑名单应用即刻判定违规）");
    m_strictModeBox->setChecked(true);
    modeLayout->addWidget(m_strictModeBox);

    auto *modeHint = new QLabel("温和模式：切屏不判违规，但专注成功后金币减半");
    modeHint->setObjectName("hintLabel");
    modeHint->setWordWrap(true);
    modeLayout->addWidget(modeHint);

    mainLayout->addWidget(modeGroup);

    // ── 黑名单 ──
    auto *blGroup = new QGroupBox("黑名单管理");
    auto *blLayout = new QVBoxLayout(blGroup);

    auto *blHint = new QLabel("专注时切到以下应用将被判定违规。进程名不区分大小写。");
    blHint->setObjectName("hintLabel");
    blHint->setWordWrap(true);
    blLayout->addWidget(blHint);

    m_blacklistWidget = new QListWidget;
    m_blacklistWidget->setMinimumHeight(160);
    m_blacklistWidget->setAlternatingRowColors(true);
    blLayout->addWidget(m_blacklistWidget);

    auto *inputRow = new QHBoxLayout;
    m_addInput = new QLineEdit;
    m_addInput->setPlaceholderText("输入进程名，如 wechat.exe");
    m_addBtn = new QPushButton("添加");
    m_addBtn->setObjectName("primaryBtn");
    m_removeBtn = new QPushButton("移除选中");
    m_removeBtn->setObjectName("dangerBtn");
    inputRow->addWidget(m_addInput, 1);
    inputRow->addWidget(m_addBtn);
    inputRow->addWidget(m_removeBtn);
    blLayout->addLayout(inputRow);

    mainLayout->addWidget(blGroup);

    mainLayout->addStretch();

    // ── 连接 ──
    connect(m_addBtn, &QPushButton::clicked, this, [this]() {
        QString text = m_addInput->text().trimmed();
        if (text.isEmpty()) return;
        emit addBlacklistRequested(text);
        m_blacklistWidget->addItem(text);
        m_addInput->clear();
    });

    connect(m_removeBtn, &QPushButton::clicked, this, [this]() {
        auto *item = m_blacklistWidget->currentItem();
        if (!item) return;
        QString text = item->text();
        emit removeBlacklistRequested(text);
        delete m_blacklistWidget->takeItem(m_blacklistWidget->row(item));
    });

    connect(m_strictModeBox, &QCheckBox::toggled,
            this, &SettingsDialog::strictModeChanged);
}

void SettingsDialog::setBlacklist(const QStringList &list)
{
    m_blacklistWidget->clear();
    m_blacklistWidget->addItems(list);
}

void SettingsDialog::setStrictMode(bool strict)
{
    m_strictModeBox->setChecked(strict);
}

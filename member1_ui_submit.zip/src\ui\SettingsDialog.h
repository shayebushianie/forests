#ifndef SETTINGSDIALOG_H
#define SETTINGSDIALOG_H

#include <QWidget>
#include <QListWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QCheckBox>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGroupBox>

class SettingsDialog : public QWidget {
    Q_OBJECT
public:
    explicit SettingsDialog(QWidget *parent = nullptr);

    void setBlacklist(const QStringList &list);
    void setStrictMode(bool strict);

signals:
    void addBlacklistRequested(const QString &process);
    void removeBlacklistRequested(const QString &process);
    void strictModeChanged(bool enabled);

private:
    void setupUI();

    QListWidget *m_blacklistWidget = nullptr;
    QLineEdit *m_addInput = nullptr;
    QPushButton *m_addBtn = nullptr;
    QPushButton *m_removeBtn = nullptr;
    QCheckBox *m_strictModeBox = nullptr;
    QLabel *m_hintLabel = nullptr;
};

#endif // SETTINGSDIALOG_H

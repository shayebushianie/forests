#ifndef SETTINGSDIALOG_H
#define SETTINGSDIALOG_H

#include <QWidget>
#include <QListWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QCheckBox>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGroupBox>

/**
 * @brief 设置页面，管理黑白名单和严格/温和模式切换
 *
 * 用户可添加/删除进程名到黑名单，勾选严格模式复选框。
 * 所有修改通过信号通知 FocusController。
 */
class SettingsDialog : public QWidget {
    Q_OBJECT
public:
    explicit SettingsDialog(QWidget *parent = nullptr);

    /**
     * @brief 从控制器同步黑名单列表到 UI
     * @param list 当前黑名单进程名列表
     */
    void setBlacklist(const QStringList &list);

    /**
     * @brief 设置严格模式复选框状态
     * @param strict 是否开启严格模式
     */
    void setStrictMode(bool strict);

signals:
    /** 用户点击添加黑名单进程 */
    void addBlacklistRequested(const QString &process);
    /** 用户选中并移除某个黑名单项 */
    void removeBlacklistRequested(const QString &process);
    /** 严格模式复选框状态变化 */
    void strictModeChanged(bool enabled);

private:
    void setupUI();

    QListWidget *m_blacklistWidget = nullptr;
    QLineEdit *m_addInput = nullptr;
    QPushButton *m_addBtn = nullptr;
    QPushButton *m_removeBtn = nullptr;
    QCheckBox *m_strictModeBox = nullptr;
    QLabel *m_hintLabel = nullptr;
};

#endif // SETTINGSDIALOG_H

#include "ui/StatisticsDialog.h"
#include "ui/PieChartWidget.h"
#include <QFont>
#include <QFrame>
#include <QGridLayout>

StatisticsDialog::StatisticsDialog(QWidget *parent)
    : QWidget(parent)
{
    setupUI();
}

void StatisticsDialog::setupUI()
{
    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(16);
    mainLayout->setContentsMargins(24, 24, 24, 24);

    auto *header = new QLabel("数据统计");
    QFont hFont("Microsoft YaHei", 18, QFont::Bold);
    header->setFont(hFont);
    header->setObjectName("pageTitle");
    mainLayout->addWidget(header);

    // 指标卡片行
    auto *cardRow = new QHBoxLayout;
    cardRow->setSpacing(12);

    auto makeStatCard = [](const QString &title, QLabel *&valueLabel) -> QFrame * {
        auto *card = new QFrame;
        card->setObjectName("statCard");
        auto *l = new QVBoxLayout(card);
        l->setSpacing(4);

        auto *t = new QLabel(title);
        t->setObjectName("statCardTitle");
        l->addWidget(t);

        valueLabel = new QLabel("--");
        valueLabel->setObjectName("statCardValue");
        l->addWidget(valueLabel);

        return card;
    };

    cardRow->addWidget(makeStatCard("专注次数", m_totalSessions));
    cardRow->addWidget(makeStatCard("总时长(小时)", m_totalHours));
    cardRow->addWidget(makeStatCard("成功率", m_successRate));

    mainLayout->addLayout(cardRow);

    // 饼图
    m_chart = new PieChartWidget;
    m_chart->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    mainLayout->addWidget(m_chart, 1);
}

void StatisticsDialog::setChartData(const QList<PieSlice> &slices)
{
    if (m_chart) m_chart->setData(slices);
}

void StatisticsDialog::setTotalSessions(int count)
{
    if (m_totalSessions) m_totalSessions->setText(QString::number(count));
}

void StatisticsDialog::setTotalHours(double hours)
{
    if (m_totalHours) m_totalHours->setText(QString::number(hours, 'f', 1));
}

void StatisticsDialog::setSuccessRate(double rate)
{
    if (m_successRate) m_successRate->setText(QString("%1%").arg(rate, 0, 'f', 1));
}

#ifndef STATISTICSDIALOG_H
#define STATISTICSDIALOG_H

#include <QWidget>
#include <QLabel>
#include <QComboBox>
#include <QVBoxLayout>
#include <QHBoxLayout>

class PieChartWidget;
struct PieSlice;

/**
 * @brief 统计数据页面，包含甜甜圈饼图和汇总数据卡片
 *
 * 使用 PieChartWidget 展示标签分布，下方显示总次数、总时长和成功率。
 * 支持按周/月/全部切换统计周期。
 */
class StatisticsDialog : public QWidget {
    Q_OBJECT
public:
    explicit StatisticsDialog(QWidget *parent = nullptr);

    /**
     * @brief 设置饼图数据
     * @param slices 各标签及对应的分钟数
     */
    void setChartData(const QList<PieSlice> &slices);

    /**
     * @brief 更新总专注次数
     */
    void setTotalSessions(int count);

    /**
     * @brief 更新总专注时长
     * @param hours 小时数
     */
    void setTotalHours(double hours);

    /**
     * @brief 更新成功率
     * @param rate 成功率（0.0 ~ 1.0）
     */
    void setSuccessRate(double rate);

private:
    void setupUI();

    PieChartWidget *m_chart = nullptr;
    QLabel *m_totalSessions = nullptr;
    QLabel *m_totalHours = nullptr;
    QLabel *m_successRate = nullptr;
    QComboBox *m_periodCombo = nullptr;
};

#endif // STATISTICSDIALOG_H

#ifndef STATISTICSDIALOG_H
#define STATISTICSDIALOG_H

#include <QWidget>
#include <QLabel>
#include <QComboBox>
#include <QVBoxLayout>
#include <QHBoxLayout>

class PieChartWidget;
struct PieSlice;

class StatisticsDialog : public QWidget {
    Q_OBJECT
public:
    explicit StatisticsDialog(QWidget *parent = nullptr);

    void setChartData(const QList<PieSlice> &slices);
    void setTotalSessions(int count);
    void setTotalHours(double hours);
    void setSuccessRate(double rate);

private:
    void setupUI();

    PieChartWidget *m_chart = nullptr;
    QLabel *m_totalSessions = nullptr;
    QLabel *m_totalHours = nullptr;
    QLabel *m_successRate = nullptr;
    QComboBox *m_periodCombo = nullptr;
};

#endif // STATISTICSDIALOG_H

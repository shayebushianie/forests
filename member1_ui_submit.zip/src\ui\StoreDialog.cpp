#include "ui/StoreDialog.h"
#include <QMessageBox>
#include <QFont>
#include <QGraphicsOpacityEffect>

StoreDialog::StoreDialog(QWidget *parent)
    : QWidget(parent)
{
    setupUI();
}

void StoreDialog::setupUI()
{
    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(16);
    mainLayout->setContentsMargins(24, 24, 24, 24);

    auto *header = new QLabel("金币商城");
    QFont hFont("Microsoft YaHei", 18, QFont::Bold);
    header->setFont(hFont);
    header->setObjectName("pageTitle");
    mainLayout->addWidget(header);

    m_balanceLabel = new QLabel("当前金币: 0");
    m_balanceLabel->setObjectName("balanceLabel");
    m_balanceLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(m_balanceLabel);

    auto *scroll = new QScrollArea;
    scroll->setWidgetResizable(true);
    scroll->setObjectName("storeScroll");

    auto *scrollContent = new QWidget;
    m_cardGrid = new QGridLayout(scrollContent);
    m_cardGrid->setSpacing(16);
    m_cardGrid->setContentsMargins(0, 8, 0, 8);
    scroll->setWidget(scrollContent);

    mainLayout->addWidget(scroll, 1);

    // 预设 5 种商品
    QList<StoreItem> defaults = {
        {0, "橡树",   "生长稳健，树冠茂密", 500,  true},
        {1, "松树",   "耐寒长青，坚韧不拔", 600,  false},
        {2, "玫瑰",   "娇艳欲滴，需悉心呵护", 700, false},
        {3, "向日葵", "向阳而生，生长迅捷", 400, false},
        {4, "樱花树", "落英缤纷，稀有品种", 1000, false},
    };
    setItems(defaults);
}

QFrame *StoreDialog::createCard(const StoreItem &item)
{
    auto *card = new QFrame;
    card->setObjectName("storeCard");
    card->setMinimumSize(160, 200);
    card->setMaximumWidth(220);

    auto *layout = new QVBoxLayout(card);
    layout->setSpacing(8);
    layout->setContentsMargins(12, 16, 12, 12);

    auto *icon = new QLabel("🌱");
    icon->setAlignment(Qt::AlignCenter);
    icon->setStyleSheet("font-size: 40px;");

    auto *nameLabel = new QLabel(item.name);
    nameLabel->setObjectName("cardName");
    nameLabel->setAlignment(Qt::AlignCenter);

    auto *descLabel = new QLabel(item.description);
    descLabel->setObjectName("cardDesc");
    descLabel->setAlignment(Qt::AlignCenter);
    descLabel->setWordWrap(true);

    auto *priceLabel = new QLabel(QString("%1 金币").arg(item.price));
    priceLabel->setObjectName("cardPrice");
    priceLabel->setAlignment(Qt::AlignCenter);

    auto *btn = new QPushButton;
    if (item.unlocked) {
        btn->setText("已解锁");
        btn->setEnabled(false);
        btn->setObjectName("unlockedBtn");
    } else {
        btn->setText("购买");
        btn->setObjectName("primaryBtn");
        btn->setEnabled(m_balance >= item.price);
        connect(btn, &QPushButton::clicked, this, [this, item]() {
            if (m_balance < item.price) {
                QMessageBox::information(this, "金币不足",
                    QString("需要 %1 金币，当前余额 %2").arg(item.price).arg(m_balance));
                return;
            }
            emit purchaseRequested(item.plantId);
        });
    }

    layout->addWidget(icon);
    layout->addWidget(nameLabel);
    layout->addWidget(descLabel);
    layout->addWidget(priceLabel);
    layout->addWidget(btn);

    return card;
}

void StoreDialog::setItems(const QList<StoreItem> &items)
{
    m_items = items;

    // 清除旧卡片
    QLayoutItem *child;
    while ((child = m_cardGrid->takeAt(0)) != nullptr) {
        if (child->widget()) child->widget()->deleteLater();
        delete child;
    }

    int cols = 3;
    for (int i = 0; i < items.size(); i++) {
        m_cardGrid->addWidget(createCard(items[i]), i / cols, i % cols);
    }
}

void StoreDialog::setCoinBalance(int balance)
{
    m_balance = balance;
    m_balanceLabel->setText(QString("当前金币: %1").arg(balance));
}

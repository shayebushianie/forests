#ifndef STOREDIALOG_H
#define STOREDIALOG_H

#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QScrollArea>
#include <QFrame>

/**
 * @brief 商城商品数据结构
 */
struct StoreItem {
    int plantId = 0;
    QString name;
    QString description;
    int price = 500;
    bool unlocked = false;
};

/**
 * @brief 商城页面，展示可解锁植物卡片列表
 *
 * 以卡片式网格布局显示 5 种植物，展示名称、价格、描述和解锁状态。
 * 用户点击已解锁/金币足够的植物卡片时发出购买信号。
 */
class StoreDialog : public QWidget {
    Q_OBJECT
public:
    explicit StoreDialog(QWidget *parent = nullptr);

    /**
     * @brief 设置商品列表
     * @param items 商城商品数据
     */
    void setItems(const QList<StoreItem> &items);

    /**
     * @brief 更新金币余额显示
     * @param balance 当前金币数
     */
    void setCoinBalance(int balance);

signals:
    /** 用户点击购买某个植物 */
    void purchaseRequested(int plantId);

private:
    void setupUI();
    QFrame *createCard(const StoreItem &item);

    QLabel *m_balanceLabel = nullptr;
    QGridLayout *m_cardGrid = nullptr;
    QList<StoreItem> m_items;
    int m_balance = 0;
};

#endif // STOREDIALOG_H

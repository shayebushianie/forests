#ifndef STOREDIALOG_H
#define STOREDIALOG_H

#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QScrollArea>
#include <QFrame>

struct StoreItem {
    int plantId = 0;
    QString name;
    QString description;
    int price = 500;
    bool unlocked = false;
};

class StoreDialog : public QWidget {
    Q_OBJECT
public:
    explicit StoreDialog(QWidget *parent = nullptr);

    void setItems(const QList<StoreItem> &items);
    void setCoinBalance(int balance);

signals:
    void purchaseRequested(int plantId);

private:
    void setupUI();
    QFrame *createCard(const StoreItem &item);

    QLabel *m_balanceLabel = nullptr;
    QGridLayout *m_cardGrid = nullptr;
    QList<StoreItem> m_items;
    int m_balance = 0;
};

#endif // STOREDIALOG_H

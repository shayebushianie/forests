#include "ui/TimerRing.h"
#include <QtMath>
#include <QFont>
#include <QLinearGradient>
#include <QCursor>
#include <QApplication>

TimerRing::TimerRing(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(280, 280);
    setCursor(Qt::PointingHandCursor);
    m_durationMinutes = 25;
    m_totalSeconds = m_durationMinutes * 60;
    m_remainingSeconds = m_totalSeconds;
}

void TimerRing::setRunning(bool running)
{
    m_running = running;
    update();
}

void TimerRing::setDuration(int minutes)
{
    m_durationMinutes = qBound(MIN_DURATION, minutes, MAX_DURATION);
    m_totalSeconds = m_durationMinutes * 60;
    m_remainingSeconds = m_totalSeconds;
    update();
}

void TimerRing::reset()
{
    m_remainingSeconds = m_totalSeconds;
    m_running = false;
    update();
}

void TimerRing::onTick(int remainingSeconds, int totalSeconds)
{
    m_remainingSeconds = remainingSeconds;
    m_totalSeconds = totalSeconds;
    m_durationMinutes = totalSeconds / 60;
    update();
}

void TimerRing::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    m_centerX = width() / 2.0;
    m_centerY = height() / 2.0;
    m_radius = qMin(m_centerX, m_centerY) - 20;
    drawRing(p);
    drawTime(p);
}

void TimerRing::drawRing(QPainter &p)
{
    QPen bgPen(QColor("#2D3A2E"), 14, Qt::SolidLine, Qt::RoundCap);
    p.setPen(bgPen);
    p.drawArc(QRectF(m_centerX - m_radius, m_centerY - m_radius,
                     m_radius * 2, m_radius * 2), 90 * 16, -360 * 16);

    if (m_totalSeconds <= 0) return;

    double fraction = 1.0 - (double)m_remainingSeconds / m_totalSeconds;
    int spanAngle = (int)(fraction * 360 * 16);

    QPen progressPen;
    if (m_running) {
        QLinearGradient grad(m_centerX - m_radius, 0, m_centerX + m_radius, 0);
        grad.setColorAt(0.0, QColor("#4CAF50"));
        grad.setColorAt(0.5, QColor("#8BC34A"));
        grad.setColorAt(1.0, QColor("#CDDC39"));
        progressPen.setBrush(grad);
    } else {
        progressPen.setColor(QColor("#607D8B"));
    }
    progressPen.setWidth(14);
    progressPen.setCapStyle(Qt::RoundCap);
    p.setPen(progressPen);
    p.drawArc(QRectF(m_centerX - m_radius, m_centerY - m_radius,
                     m_radius * 2, m_radius * 2), 90 * 16, -spanAngle);
}

void TimerRing::drawTime(QPainter &p)
{
    QFont timeFont("Arial", (int)(m_radius * 0.35), QFont::Bold);
    p.setFont(timeFont);
    p.setPen(QColor("#E0E0E0"));

    QString text;
    if (m_running) {
        text = formatTime(m_remainingSeconds);
    } else if (m_dragging) {
        text = QString("%1 min").arg(m_durationMinutes);
    } else {
        text = formatTime(m_durationMinutes * 60);
    }

    p.drawText(QRectF(m_centerX - m_radius, m_centerY - m_radius,
                      m_radius * 2, m_radius * 2), Qt::AlignCenter, text);

    if (!m_running && !m_dragging) {
        QFont labelFont("Microsoft YaHei", (int)(m_radius * 0.12));
        p.setFont(labelFont);
        p.setPen(QColor("#9E9E9E"));
        p.drawText(QRectF(m_centerX - m_radius, m_centerY + m_radius * 0.15,
                          m_radius * 2, m_radius * 0.25),
                   Qt::AlignHCenter | Qt::AlignTop, "拖动圆环设置时间");
    }
}

QString TimerRing::formatTime(int seconds) const
{
    int m = seconds / 60;
    int s = seconds % 60;
    return QString("%1:%2").arg(m, 2, 10, QChar('0')).arg(s, 2, 10, QChar('0'));
}

void TimerRing::mousePressEvent(QMouseEvent *event)
{
    if (m_running) {
        if (event->button() == Qt::LeftButton) {
            QPointF c(m_centerX, m_centerY);
            QPointF p = event->position() - c;
            double dist = qSqrt(p.x() * p.x() + p.y() * p.y());
            if (dist > m_radius * 0.7 && dist < m_radius * 1.3) {
                emit pauseRequested();
            }
        } else if (event->button() == Qt::RightButton) {
            emit abandonRequested();
        }
        return;
    }

    m_dragging = true;
    setCursor(Qt::ClosedHandCursor);
    updateAngle(event->position());
}

void TimerRing::mouseMoveEvent(QMouseEvent *event)
{
    if (m_dragging && !m_running) {
        updateAngle(event->position());
    }
}

void TimerRing::mouseReleaseEvent(QMouseEvent *event)
{
    if (m_dragging) {
        m_dragging = false;
        setCursor(Qt::PointingHandCursor);

        QPointF c(m_centerX, m_centerY);
        QPointF p = event->position() - c;
        double dist = qSqrt(p.x() * p.x() + p.y() * p.y());
        if (dist < m_radius * 0.7) {
            emit startRequested(m_durationMinutes);
        } else {
            emit startRequested(m_durationMinutes);
        }
        update();
    }
}

void TimerRing::resizeEvent(QResizeEvent *)
{
    m_centerX = width() / 2.0;
    m_centerY = height() / 2.0;
    m_radius = qMin(m_centerX, m_centerY) - 20;
}

void TimerRing::updateAngle(const QPointF &pos)
{
    QPointF c(m_centerX, m_centerY);
    QPointF v = pos - c;
    double dist = qSqrt(v.x() * v.x() + v.y() * v.y());
    if (dist < m_radius * 0.5) return;

    double angle = qAtan2(-v.y(), v.x());
    if (angle < 0) angle += 2 * M_PI;

    double minutes = angle / (2 * M_PI) * MAX_DURATION;
    minutes = qBound((double)MIN_DURATION, minutes, (double)MAX_DURATION);
    minutes = qRound(minutes / STEP_MINUTES) * STEP_MINUTES;
    m_durationMinutes = (int)minutes;
    m_totalSeconds = m_durationMinutes * 60;
    m_remainingSeconds = m_totalSeconds;
    m_angleOffset = angle;
    update();
}

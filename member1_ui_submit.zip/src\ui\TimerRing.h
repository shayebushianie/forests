#ifndef TIMERRING_H
#define TIMERRING_H

#include <QWidget>
#include <QTimer>
#include <QPainter>
#include <QMouseEvent>

/**
 * @brief 圆形倒计时进度环，支持拖拽设置时长和实时进度显示
 *
 * 使用 QPainter 手绘环形进度条，用户可通过鼠标拖拽环边缘调整时长（10-120 分钟，5 分钟步进）。
 * 接收 FocusController 的 tick 信号来更新剩余时间和进度角度。
 */
class TimerRing : public QWidget {
    Q_OBJECT
public:
    explicit TimerRing(QWidget *parent = nullptr);

    /**
     * @brief 设置运行状态，影响颜色和交互行为
     */
    void setRunning(bool running);

    /**
     * @brief 设置倒计时总时长
     * @param minutes 分钟数（10-120）
     */
    void setDuration(int minutes);

    /**
     * @brief 重置到默认 25 分钟
     */
    void reset();

    /**
     * @brief 当前设定时长（分钟）
     */
    int durationMinutes() const { return m_durationMinutes; }

public slots:
    /**
     * @brief 接收每秒 tick 信号，更新剩余时间和重绘
     * @param remainingSeconds 剩余秒数
     * @param totalSeconds 总秒数
     */
    void onTick(int remainingSeconds, int totalSeconds);

signals:
    /** 用户拖拽圆环后触发的开始请求 */
    void startRequested(int durationMinutes);
    void pauseRequested();
    void resumeRequested();
    void abandonRequested();

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private:
    void drawRing(QPainter &p);
    void drawTime(QPainter &p);
    QString formatTime(int seconds) const;
    void updateAngle(const QPointF &pos);

    int m_durationMinutes = 25;
    int m_remainingSeconds = 0;
    int m_totalSeconds = 0;
    bool m_running = false;
    bool m_dragging = false;
    double m_angleOffset = 0;

    qreal m_centerX = 0, m_centerY = 0, m_radius = 0;

    static constexpr int MIN_DURATION = 10;
    static constexpr int MAX_DURATION = 120;
    static constexpr int STEP_MINUTES = 5;
};

#endif // TIMERRING_H

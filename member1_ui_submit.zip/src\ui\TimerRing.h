#ifndef TIMERRING_H
#define TIMERRING_H

#include <QWidget>
#include <QTimer>
#include <QPainter>
#include <QMouseEvent>

class TimerRing : public QWidget {
    Q_OBJECT
public:
    explicit TimerRing(QWidget *parent = nullptr);

    void setRunning(bool running);
    void setDuration(int minutes);
    void reset();

    int durationMinutes() const { return m_durationMinutes; }

public slots:
    void onTick(int remainingSeconds, int totalSeconds);

signals:
    void startRequested(int durationMinutes);
    void pauseRequested();
    void resumeRequested();
    void abandonRequested();

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private:
    void drawRing(QPainter &p);
    void drawTime(QPainter &p);
    QString formatTime(int seconds) const;
    void updateAngle(const QPointF &pos);

    int m_durationMinutes = 25;
    int m_remainingSeconds = 0;
    int m_totalSeconds = 0;
    bool m_running = false;
    bool m_dragging = false;
    double m_angleOffset = 0;

    qreal m_centerX = 0, m_centerY = 0, m_radius = 0;

    static constexpr int MIN_DURATION = 10;
    static constexpr int MAX_DURATION = 120;
    static constexpr int STEP_MINUTES = 5;
};

#endif // TIMERRING_H

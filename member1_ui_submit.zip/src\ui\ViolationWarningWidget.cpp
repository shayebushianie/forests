#include "ui/ViolationWarningWidget.h"
#include <QPainter>
#include <QPainterPath>
#include <QFont>
#include <QPropertyAnimation>
#include <QScreen>
#include <QGuiApplication>

ViolationWarningWidget::ViolationWarningWidget(QWidget *parent)
    : QWidget(parent)
{
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint |
                   Qt::Tool | Qt::SubWindow);
    setAttribute(Qt::WA_TranslucentBackground);
    setAttribute(Qt::WA_ShowWithoutActivating);
    setFixedSize(500, 320);

    m_fadeEffect = new QGraphicsOpacityEffect(this);
    m_fadeEffect->setOpacity(0.0);
    setGraphicsEffect(m_fadeEffect);

    auto *layout = new QVBoxLayout(this);
    layout->setContentsMargins(40, 30, 40, 30);
    layout->setSpacing(12);

    m_titleLabel = new QLabel("⚠ 违规警告");
    m_titleLabel->setObjectName("violationTitle");
    m_titleLabel->setAlignment(Qt::AlignCenter);
    QFont titleFont("Microsoft YaHei", 20, QFont::Bold);
    m_titleLabel->setFont(titleFont);

    m_processLabel = new QLabel;
    m_processLabel->setObjectName("violationProcess");
    m_processLabel->setAlignment(Qt::AlignCenter);
    QFont procFont("Consolas", 13);
    m_processLabel->setFont(procFont);

    m_countdownLabel = new QLabel;
    m_countdownLabel->setObjectName("violationCountdown");
    m_countdownLabel->setAlignment(Qt::AlignCenter);
    QFont cdFont("Arial", 48, QFont::Bold);
    m_countdownLabel->setFont(cdFont);

    m_hintLabel = new QLabel("请立即切回专注窗口，否则植物将枯萎！");
    m_hintLabel->setObjectName("hintLabel");
    m_hintLabel->setAlignment(Qt::AlignCenter);
    m_hintLabel->setWordWrap(true);

    layout->addWidget(m_titleLabel);
    layout->addWidget(m_processLabel);
    layout->addWidget(m_countdownLabel);
    layout->addWidget(m_hintLabel);

    m_timer = new QTimer(this);
    m_timer->setInterval(1000);
    connect(m_timer, &QTimer::timeout, this, &ViolationWarningWidget::onTimerTick);
}

void ViolationWarningWidget::show(const QString &processName)
{
    m_countdown = 10;
    m_processLabel->setText(QString("检测到违规进程: %1").arg(processName));
    m_countdownLabel->setText("10");

    // 居中到屏幕
    QScreen *screen = QGuiApplication::primaryScreen();
    if (screen) {
        QRect sr = screen->geometry();
        move((sr.width() - width()) / 2, (sr.height() - height()) / 2);
    }

    m_fadeEffect->setOpacity(0.0);
    QWidget::show();
    raise();

    auto *anim = new QPropertyAnimation(m_fadeEffect, "opacity", this);
    anim->setDuration(300);
    anim->setStartValue(0.0);
    anim->setEndValue(1.0);
    anim->start(QAbstractAnimation::DeleteWhenStopped);

    m_timer->start();
}

void ViolationWarningWidget::hide()
{
    m_timer->stop();
    QWidget::hide();
}

void ViolationWarningWidget::onTimerTick()
{
    m_countdown--;
    m_countdownLabel->setText(QString::number(m_countdown));

    if (m_countdown <= 0) {
        m_timer->stop();
        hide();
        emit warningTimeout();
    }
}

void ViolationWarningWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    QPainterPath path;
    path.addRoundedRect(rect(), 16, 16);
    p.fillPath(path, QColor(25, 15, 15, 245));
    p.setPen(QPen(QColor("#F44336"), 3));
    p.drawPath(path);
}

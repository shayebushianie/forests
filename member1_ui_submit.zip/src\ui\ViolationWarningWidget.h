#ifndef VIOLATIONWARNINGWIDGET_H
#define VIOLATIONWARNINGWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QTimer>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>

class ViolationWarningWidget : public QWidget {
    Q_OBJECT
public:
    explicit ViolationWarningWidget(QWidget *parent = nullptr);

    void show(const QString &processName);
    void hide();

public slots:
    void onTimerTick();

signals:
    void warningTimeout();        // 10秒到期，判定违规失败
    void warningDismissed();      // 用户切回来了，免罚

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QLabel *m_titleLabel = nullptr;
    QLabel *m_processLabel = nullptr;
    QLabel *m_countdownLabel = nullptr;
    QLabel *m_hintLabel = nullptr;
    QTimer *m_timer = nullptr;
    int m_countdown = 10;
    QGraphicsOpacityEffect *m_fadeEffect = nullptr;
};

#endif // VIOLATIONWARNINGWIDGET_H

#ifndef VIOLATIONWARNINGWIDGET_H
#define VIOLATIONWARNINGWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QTimer>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>

/**
 * @brief 违规全屏警告覆盖层，10 秒倒计时后判定失败
 *
 * 当 SystemMonitor 检测到黑名单进程时弹出，
 * 显示违规进程名 + 10 秒倒计时。期间用户切回则免罚，
 * 超时则发出 warningTimeout 信号通知 FocusController 判定失败。
 */
class ViolationWarningWidget : public QWidget {
    Q_OBJECT
public:
    explicit ViolationWarningWidget(QWidget *parent = nullptr);

    /**
     * @brief 显示警告并开始 10 秒倒计时
     * @param processName 被检测到的违规进程名
     */
    void show(const QString &processName);

    /**
     * @brief 隐藏警告（用户切回或手动关闭）
     */
    void hide();

public slots:
    /**
     * @brief 每秒倒计时回调，更新显示并检测是否超时
     */
    void onTimerTick();

signals:
    /** 10 秒倒计时结束，判定违规失败 */
    void warningTimeout();
    /** 用户切回前台，取消惩罚 */
    void warningDismissed();

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QLabel *m_titleLabel = nullptr;
    QLabel *m_processLabel = nullptr;
    QLabel *m_countdownLabel = nullptr;
    QLabel *m_hintLabel = nullptr;
    QTimer *m_timer = nullptr;
    int m_countdown = 10;
    QGraphicsOpacityEffect *m_fadeEffect = nullptr;
};

#endif // VIOLATIONWARNINGWIDGET_H
